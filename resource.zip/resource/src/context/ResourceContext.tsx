import React, { createContext, useContext, useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  TelemetryMetric,
  FacilityNode,
  ResourceListing,
  DemandNode,
  AnomalyAlert,
  ResourceTransfer,
  ResourcePassport,
  ImpactMetrics,
  WasteHotspotItem,
} from '../types';
import {
  INITIAL_IMPACT_METRICS,
  INITIAL_TELEMETRY,
  CAMPUS_FACILITIES,
  INITIAL_RESOURCE_LISTINGS,
  DEMAND_NODES,
  INITIAL_ALERTS,
  INITIAL_TRANSFERS,
  INITIAL_PASSPORTS,
  WASTE_HOTSPOTS,
} from '../services/mockData';

interface DemoStoryStep {
  step: number;
  title: string;
  badge: string;
  narrative: string;
  focusFacilityId?: string;
  actionLabel?: string;
}

export const DEMO_STORY_STEPS: DemoStoryStep[] = [
  {
    step: 1,
    badge: 'STEP 1: TELEMETRY ANOMALY',
    title: 'Abnormal Water Consumption Detected',
    narrative: 'Sensors flag an anomalous overnight flow spike (+18.4% above baseline) between 01:00 AM and 04:00 AM across the campus water grid.',
    focusFacilityId: 'fac-2',
    actionLabel: 'Isolate Probable Cause',
  },
  {
    step: 2,
    badge: 'STEP 2: HOTSPOT PINPOINTING',
    title: 'AI Identifies Block B Manifold W-04',
    narrative: 'Acoustic and pressure telemetry isolates the underground leak to Sub-Line W-04 in Block B (Sciences). Recommended action: Valve isolation ticket auto-drafted.',
    focusFacilityId: 'fac-2',
    actionLabel: 'Inspect Cafeteria Surplus',
  },
  {
    step: 3,
    badge: 'STEP 3: SURPLUS DETECTION',
    title: 'Central Cafeteria Lunch Overproduction',
    narrative: 'At the same time, Cafeteria A smart weighing scales register 55 kg of premium cooked meals (Rice, Dal, Veg Curry) unconsumed after lunch service.',
    focusFacilityId: 'fac-6',
    actionLabel: 'Run Expiry Prediction',
  },
  {
    step: 4,
    badge: 'STEP 4: PREDICTION ENGINE',
    title: 'Forecast Engine Calculates Expiry Window',
    narrative: 'Predictive model establishes a strict 3.5-hour safe temperature holding window. If not relocated before 17:30, all 55 kg will spoil into landfill waste.',
    focusFacilityId: 'fac-6',
    actionLabel: 'Search Demand Nodes',
  },
  {
    step: 5,
    badge: 'STEP 5: MULTI-NODE MATCHING',
    title: 'Matching Engine Evaluates Nearby Demand',
    narrative: 'System scores 3 candidate destinations. Single destination cannot safely absorb 55 kg alone. AI computes optimal dual-split: Hostel C (15 kg) + Community Kitchen B (40 kg).',
    focusFacilityId: 'fac-6',
    actionLabel: 'View AI Recommendation',
  },
  {
    step: 6,
    badge: 'STEP 6: RECOMMENDATION READY',
    title: 'Match Score 94/100 Formulated',
    narrative: 'Dual allocation absorbs 100% of surplus (55 kg), prevents 137.5 kg CO2e, and requires just 14 min transit time. High-confidence recommendation formulated.',
    focusFacilityId: 'fac-6',
    actionLabel: 'Approve & Dispatch Resource',
  },
  {
    step: 7,
    badge: 'STEP 7: 1-CLICK ALLOCATION',
    title: 'User Approves Transfer Dispatch',
    narrative: 'User clicks "Approve Match & Dispatch". The system mints Digital Passport FOOD-00482, assigns Campus EV Courier 2, and updates active routing lines.',
    focusFacilityId: 'fac-6',
    actionLabel: 'View Updated Impact',
  },
  {
    step: 8,
    badge: 'STEP 8: IMPACT SURGE',
    title: 'Resource Waste Prevented & Verified',
    narrative: '55 kg waste avoided! ?8,400 meal value saved. CO2 avoided +137.5 kg. Campus Resource Health Score surges from 87 to 92/100.',
    actionLabel: 'Restart Competition Walkthrough',
  },
];

interface ResourceContextType {
  telemetry: TelemetryMetric[];
  facilities: FacilityNode[];
  resourceListings: ResourceListing[];
  demandNodes: DemandNode[];
  alerts: AnomalyAlert[];
  transfers: ResourceTransfer[];
  impactMetrics: ImpactMetrics;
  passports: Record<string, ResourcePassport>;
  wasteHotspots: WasteHotspotItem[];
  // IoT Simulation
  isSimulating: boolean;
  toggleSimulation: () => void;
  // Demo Mode
  isDemoRunning: boolean;
  demoStep: number;
  startCompetitionDemo: () => void;
  stopCompetitionDemo: () => void;
  nextDemoStep: () => void;
  prevDemoStep: () => void;
  // Actions
  executeAllocation: (surplusId: string) => void;
  resolveAlert: (alertId: string, notes?: string) => void;
  acknowledgeAlert: (alertId: string) => void;
  assignAlert: (alertId: string, person: string) => void;
  addListing: (newListing: Partial<ResourceListing>) => void;
  claimListing: (id: string) => void;
  triggerTestAnomaly: () => void;
  // Passport Modal
  activePassportId: string | null;
  setActivePassportId: (id: string | null) => void;
}

const ResourceContext = createContext<ResourceContextType | undefined>(undefined);

export const ResourceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [telemetry, setTelemetry] = useState<TelemetryMetric[]>(INITIAL_TELEMETRY);
  const [facilities, setFacilities] = useState<FacilityNode[]>(CAMPUS_FACILITIES);
  const [resourceListings, setResourceListings] = useState<ResourceListing[]>(INITIAL_RESOURCE_LISTINGS);
  const [demandNodes] = useState<DemandNode[]>(DEMAND_NODES);
  const [alerts, setAlerts] = useState<AnomalyAlert[]>(INITIAL_ALERTS);
  const [transfers, setTransfers] = useState<ResourceTransfer[]>(INITIAL_TRANSFERS);
  const [impactMetrics, setImpactMetrics] = useState<ImpactMetrics>(INITIAL_IMPACT_METRICS);
  const [passports, setPassports] = useState<Record<string, ResourcePassport>>(INITIAL_PASSPORTS);
  const [wasteHotspots] = useState<WasteHotspotItem[]>(WASTE_HOTSPOTS);

  const [isSimulating, setIsSimulating] = useState(true);
  const [isDemoRunning, setIsDemoRunning] = useState(false);
  const [demoStep, setDemoStep] = useState(1);
  const [activePassportId, setActivePassportId] = useState<string | null>(null);

  // Live IoT Telemetry Tick
  useEffect(() => {
    if (!isSimulating) return;
    const interval = setInterval(() => {
      setTelemetry(prev =>
        prev.map(item => {
          // Subtle micro fluctuations around realistic meters (+- 0.3%)
          const jitter = (Math.random() - 0.5) * 0.006 * item.currentValue;
          const newVal = Math.round(item.currentValue + jitter);
          return {
            ...item,
            currentValue: Math.max(1, newVal),
          };
        })
      );
    }, 3500);
    return () => clearInterval(interval);
  }, [isSimulating]);

  const toggleSimulation = () => setIsSimulating(p => !p);

  const executeAllocation = (surplusId: string) => {
    // 1. Mark resource listing as ALLOCATED
    setResourceListings(prev =>
      prev.map(r => (r.id === surplusId ? { ...r, status: 'ALLOCATED', allocatedTo: 'Hostel C & Community Kitchen B' } : r))
    );

    // 2. Create active transfer
    const surplusItem = resourceListings.find(r => r.id === surplusId);
    if (surplusItem) {
      const newTrf: ResourceTransfer = {
        id: `TRF-${Math.floor(1000 + Math.random() * 9000)}`,
        resourceId: surplusItem.id,
        resourceTitle: surplusItem.title,
        category: surplusItem.category,
        quantity: surplusItem.quantity,
        unit: surplusItem.unit,
        fromNode: surplusItem.source,
        toNode: 'Hostel C & Community Kitchen B',
        startTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        eta: '14 mins',
        status: 'IN_TRANSIT',
        courier: 'Campus Green Logistics EV-1',
        carbonSavedKg: surplusItem.co2AvoidedKg,
        valueRecoveredInr: surplusItem.estimatedValueInr,
      };
      setTransfers(prev => [newTrf, ...prev]);

      // 3. Update Impact Metrics
      setImpactMetrics(prev => ({
        ...prev,
        healthScore: Math.min(100, prev.healthScore + 5),
        wastePreventedKg: prev.wastePreventedKg + surplusItem.quantity,
        foodRedirectedKg: prev.foodRedirectedKg + surplusItem.quantity,
        costRecoveredInr: prev.costRecoveredInr + surplusItem.estimatedValueInr,
        co2AvoidedTonnes: Number((prev.co2AvoidedTonnes + surplusItem.co2AvoidedKg / 1000).toFixed(2)),
      }));

      // 4. Update Passport Custody
      if (surplusItem.passportId && passports[surplusItem.passportId]) {
        setPassports(prev => ({
          ...prev,
          [surplusItem.passportId]: {
            ...prev[surplusItem.passportId],
            status: 'ALLOCATED',
            custodyHistory: [
              ...prev[surplusItem.passportId].custodyHistory,
              {
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                event: 'Dual-Allocation Match Dispatched',
                actor: 'AI Match Engine & Logistics EV-1',
                location: 'Transit Corridor East',
              },
            ],
          },
        }));
      }

      // Confetti celebration
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#10b981', '#06b6d4', '#3b82f6', '#10b981'],
        });
      } catch (e) {
        // Safe fallback
      }
    }
  };

  const resolveAlert = (alertId: string, notes?: string) => {
    setAlerts(prev =>
      prev.map(a =>
        a.id === alertId
          ? {
              ...a,
              status: 'RESOLVED',
              resolutionNotes: notes || 'Resolved via emergency technician dispatch and valve isolation.',
            }
          : a
      )
    );
  };

  const acknowledgeAlert = (alertId: string) => {
    setAlerts(prev => prev.map(a => (a.id === alertId ? { ...a, status: 'ACKNOWLEDGED' } : a)));
  };

  const assignAlert = (alertId: string, person: string) => {
    setAlerts(prev => prev.map(a => (a.id === alertId ? { ...a, status: 'ASSIGNED', assignedTo: person } : a)));
  };

  const addListing = (newListing: Partial<ResourceListing>) => {
    const id = `RES-${Math.floor(10000 + Math.random() * 90000)}`;
    const passportId = `PAS-${Math.floor(10000 + Math.random() * 90000)}`;
    const fullListing: ResourceListing = {
      id,
      title: newListing.title || 'Surplus Material Listing',
      category: newListing.category || 'Materials',
      quantity: newListing.quantity || 10,
      unit: newListing.unit || 'Units',
      condition: newListing.condition || 'Good Condition',
      source: newListing.source || 'Campus Depot',
      sourceFacilityId: newListing.sourceFacilityId || 'fac-15',
      availableUntil: newListing.availableUntil || 'In 48 hours',
      location: newListing.location || 'Central Staging',
      priority: newListing.priority || 'MEDIUM',
      estimatedValueInr: newListing.estimatedValueInr || 2500,
      co2AvoidedKg: newListing.co2AvoidedKg || 45,
      status: 'AVAILABLE',
      passportId,
    };
    setResourceListings(prev => [fullListing, ...prev]);

    // Create passport
    const newPassport: ResourcePassport = {
      id: passportId,
      resourceId: id,
      resourceName: fullListing.title,
      category: fullListing.category,
      quantity: fullListing.quantity,
      unit: fullListing.unit,
      createdTimestamp: 'Just now',
      expiryTimestamp: fullListing.availableUntil,
      sourceFacility: fullListing.source,
      currentCustodian: 'Authorized Faculty Representative',
      carbonFootprintAvoidedKg: fullListing.co2AvoidedKg,
      economicValueInr: fullListing.estimatedValueInr,
      storageRequirements: 'Standard dry ambient storage',
      safetyCertification: 'Campus Asset Verified Grade A',
      qrPayload: `https://resource.campus.edu/passport/${passportId}`,
      custodyHistory: [
        {
          timestamp: 'Just now',
          event: 'Material Registered on Circular Exchange',
          actor: 'User Custodian',
          location: fullListing.location,
        },
      ],
      status: 'AUTHENTICATED',
    };
    setPassports(prev => ({ ...prev, [passportId]: newPassport }));
  };

  const claimListing = (id: string) => {
    setResourceListings(prev =>
      prev.map(r => (r.id === id ? { ...r, status: 'MATCHED' } : r))
    );
  };

  const triggerTestAnomaly = () => {
    const newAlert: AnomalyAlert = {
      id: `alt-${Date.now().toString().slice(-4)}`,
      title: 'Lab 2 Exhaust Fan Overdraw Detected',
      severity: 'HIGH',
      resourceType: 'Energy',
      facility: 'Advanced Clean Energy Lab 2',
      deviation: '+28.5% above nocturnal baseline',
      probableCause: 'Fume hood sash left unclosed in synthesis room 102',
      recommendedAction: 'Automate sash solenoid closing and alert night duty warden',
      detectedAt: 'Just now (Live IoT telemetry)',
      status: 'DETECTED',
    };
    setAlerts(prev => [newAlert, ...prev]);
  };

  // Competition Demo Walkthrough controls
  const startCompetitionDemo = () => {
    setIsDemoRunning(true);
    setDemoStep(1);
  };

  const stopCompetitionDemo = () => {
    setIsDemoRunning(false);
  };

  const nextDemoStep = () => {
    if (demoStep === 7) {
      executeAllocation('RES-00482');
    }
    if (demoStep >= 8) {
      setDemoStep(1);
    } else {
      setDemoStep(s => s + 1);
    }
  };

  const prevDemoStep = () => {
    setDemoStep(s => Math.max(1, s - 1));
  };

  return (
    <ResourceContext.Provider
      value={{
        telemetry,
        facilities,
        resourceListings,
        demandNodes,
        alerts,
        transfers,
        impactMetrics,
        passports,
        wasteHotspots,
        isSimulating,
        toggleSimulation,
        isDemoRunning,
        demoStep,
        startCompetitionDemo,
        stopCompetitionDemo,
        nextDemoStep,
        prevDemoStep,
        executeAllocation,
        resolveAlert,
        acknowledgeAlert,
        assignAlert,
        addListing,
        claimListing,
        triggerTestAnomaly,
        activePassportId,
        setActivePassportId,
      }}
    >
      {children}
    </ResourceContext.Provider>
  );
};

export const useResource = () => {
  const context = useContext(ResourceContext);
  if (!context) {
    throw new Error('useResource must be used within a ResourceProvider');
  }
  return context;
};
