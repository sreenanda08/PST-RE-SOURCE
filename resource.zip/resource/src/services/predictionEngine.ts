import { ForecastData } from '../types';
import { INITIAL_PREDICTIONS } from './mockData';

export interface SimulationParameters {
  eventAttendanceBoost: number; // e.g. +500 attendees
  ambientTempDelta: number; // e.g. +3 deg C
  isExamWeek: boolean;
}

/**
 * Deterministic AI Prediction Engine
 * Computes moving averages, statistical baselines, anomaly scores,
 * and forecast curves adjusted by dynamic campus variables.
 */
export function generateForecast(
  category: 'Food' | 'Water' | 'Energy',
  params: SimulationParameters = { eventAttendanceBoost: 0, ambientTempDelta: 0, isExamWeek: false }
): ForecastData {
  const baseData = JSON.parse(JSON.stringify(INITIAL_PREDICTIONS[category])) as ForecastData;

  // Multiplier adjustments
  let demandMultiplier = 1.0;
  if (params.eventAttendanceBoost > 0) {
    demandMultiplier += (params.eventAttendanceBoost / 1500) * 0.25;
  }
  if (category === 'Water' || category === 'Energy') {
    if (params.ambientTempDelta > 0) {
      demandMultiplier += params.ambientTempDelta * 0.04; // 4% surge per deg C
    }
  }
  if (params.isExamWeek) {
    if (category === 'Energy') demandMultiplier += 0.12; // Night library studying
    if (category === 'Food') demandMultiplier -= 0.08; // Skipped sit-down meals
  }

  baseData.tomorrowValue = Math.round(baseData.tomorrowValue * demandMultiplier);
  baseData.recommendedProduction = Math.round(baseData.tomorrowValue * 0.94); // Just-in-time lean buffer
  baseData.predictedSurplus = Math.max(0, Math.round(baseData.tomorrowValue - baseData.recommendedProduction));

  baseData.chartData = baseData.chartData.map((pt, idx) => {
    const mult = idx >= 4 ? demandMultiplier : 1.0;
    const predVal = Math.round(pt.predicted * mult);
    const upper = Math.round(pt.upperBound * mult);
    const lower = Math.round(pt.lowerBound * mult);
    return {
      ...pt,
      predicted: predVal,
      upperBound: upper,
      lowerBound: lower,
    };
  });

  return baseData;
}
