import { AiMessage } from '../types';

/**
 * Deterministic AI Resource Copilot Engine ("SOURCE AI")
 * Performs semantic intent classification and contextual data synthesis
 * across campus IoT meters, alerts, and matching models.
 */
export function querySourceAi(prompt: string): AiMessage {
  const p = prompt.toLowerCase();

  // 1. Efficiency / Why did waste increase / fall
  if (p.includes('efficiency') || p.includes('waste increase') || p.includes('fall') || p.includes('why did waste')) {
    return {
      id: `ai-${Date.now()}`,
      sender: 'assistant',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      text: 'RESOURCE EFFICIENCY FELL 8.4% TODAY.',
      structuredDetails: {
        title: 'Top Inefficiency Contributors',
        stats: [
          { label: '01 Food Waste (Cafeteria A)', value: '+21% over baseline', color: 'text-rose-400' },
          { label: '02 Water Flow (Block B)', value: '+18.4% abnormal draw', color: 'text-amber-400' },
          { label: '03 HVAC Power (Block A)', value: '+9.2% post-18:00', color: 'text-cyan-400' },
        ],
        causes: [
          'Central Cafeteria overproduction (55 kg prepared above baseline) due to mid-week schedule changes.',
          'Overnight continuous pressurized leak in Block B manifold between 01:00 AM and 04:00 AM.',
          'Block A chiller manual thermostat override keeping zone 4 at 19�C after hours.',
        ],
        actions: [
          { label: 'Calibrate Tomorrow Production (-14%)', route: '/forecast', actionType: 'calibrate_production' },
          { label: 'Isolate Block B Valve W-04', route: '/alerts', actionType: 'isolate_valve' },
          { label: 'Reset BMS Chiller Setpoint to 24.5�C', route: '/resources', actionType: 'reset_chiller' },
        ],
      },
    };
  }

  // 2. What should I fix first / Priority / Next Best Action
  if (p.includes('fix first') || p.includes('priority') || p.includes('what should i do') || p.includes('action')) {
    return {
      id: `ai-${Date.now()}`,
      sender: 'assistant',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      text: 'PRIMARY DIRECTIVE: ISOLATE VALVE W-04 IN BLOCK B DISTRIBUTION LINE.',
      structuredDetails: {
        title: 'Next Best Action Prioritization (Impact � Urgency � Confidence)',
        stats: [
          { label: 'Urgency Rating', value: 'CRITICAL (Active Loss)', color: 'text-rose-400' },
          { label: 'Rate of Loss', value: '410 Liters / Hour', color: 'text-amber-400' },
          { label: 'Preventable Loss', value: '2,400 � 3,100 L / day', color: 'text-emerald-400' },
        ],
        causes: [
          'Continuous anomalous water flow detected during silent hours (01:00 AM - 04:00 AM).',
          'Delaying action past 4 hours will result in approx. 1,640 L of treated water wasted and structural moisture risk.',
        ],
        actions: [
          { label: 'View Alert ALT-001 & Assign Technician', route: '/alerts', actionType: 'view_alert' },
          { label: 'Inspect Sub-Meter on Campus Map', route: '/map', actionType: 'view_map' },
        ],
      },
    };
  }

  // 3. Where are we wasting water
  if (p.includes('water') || p.includes('leak')) {
    return {
      id: `ai-${Date.now()}`,
      sender: 'assistant',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      text: 'WATER ANOMALY LOCALIZED: BLOCK B SCIENCES WING.',
      structuredDetails: {
        title: 'Campus Water Audit Breakdown',
        stats: [
          { label: 'Block B Consumption', value: '6,800 L (Baseline: 4,600 L)', color: 'text-rose-400' },
          { label: 'Variance', value: '+47.8% localized anomaly', color: 'text-rose-400' },
          { label: 'Estimated Run-Off Loss', value: '?4,800 / week', color: 'text-amber-400' },
        ],
        causes: [
          'Sub-meter M-B1 reported 580 L/hr at 02:00 AM when baseline occupancy was 0.',
          'Telemetry acoustic signature matches pipe joint fissure along underground lateral 4.',
        ],
        actions: [
          { label: 'Dispatch Plumbing Dispatch Ticket', route: '/alerts', actionType: 'dispatch_ticket' },
          { label: 'Switch Supply to Backup Harvesting Cistern', route: '/resources', actionType: 'switch_supply' },
        ],
      },
    };
  }

  // 4. Which resource should be moved / Surplus allocation
  if (p.includes('move') || p.includes('transfer') || p.includes('surplus') || p.includes('match')) {
    return {
      id: `ai-${Date.now()}`,
      sender: 'assistant',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      text: 'OPTIMAL RESOURCE MOVEMENT: 55 KG SURPLUS MEALS AT CENTRAL CAFETERIA.',
      structuredDetails: {
        title: 'AI Multi-Destination Match Plan',
        stats: [
          { label: 'Surplus Ready', value: '55 kg Cooked Meals', color: 'text-amber-400' },
          { label: 'Destinations', value: 'Hostel Block C (15 kg) + Community Kitchen B (40 kg)', color: 'text-emerald-400' },
          { label: 'Match Confidence', value: '94 / 100 Score', color: 'text-emerald-400' },
          { label: 'Est. Transit Time', value: '14 minutes', color: 'text-cyan-400' },
        ],
        causes: [
          'Expiry threshold is in 3.2 hours. A single destination cannot absorb 55 kg alone before safe holding window expires.',
          'Dual split guarantees 100% waste avoidance and recovers ?8,400 in direct meal value.',
        ],
        actions: [
          { label: 'Approve Dual Allocation in Match Center', route: '/matches', actionType: 'open_matches' },
          { label: 'Generate Digital Food Passport', route: '/exchange', actionType: 'view_passport' },
        ],
      },
    };
  }

  // 5. How much food will become surplus tomorrow
  if (p.includes('food') || p.includes('tomorrow') || p.includes('meals')) {
    return {
      id: `ai-${Date.now()}`,
      sender: 'assistant',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      text: 'TOMORROW FORECAST: 463 MEALS DEMAND WITH 37 MEALS PREDICTED SURPLUS.',
      structuredDetails: {
        title: 'Dining Predictive Planning',
        stats: [
          { label: 'Forecasted Demand', value: '463 Meals', color: 'text-cyan-400' },
          { label: 'Recommended Prep', value: '438 Meals (Lean Target)', color: 'text-emerald-400' },
          { label: 'Predicted Surplus Reduction', value: '86% waste avoided', color: 'text-emerald-400' },
          { label: 'Forecast Confidence', value: '91% (Historical Bayesian Model)', color: 'text-indigo-400' },
        ],
        causes: [
          'Historical Friday dining curve shows 11% dip in evening cafeteria footfall due to weekend departures.',
          'Adjusting morning prep to 438 meals prevents 37 kg of perishable overproduction.',
        ],
        actions: [
          { label: 'Apply Lean Kitchen Production Plan', route: '/forecast', actionType: 'apply_plan' },
        ],
      },
    };
  }

  // 6. What saved us the most money this month / Savings
  if (p.includes('money') || p.includes('saved') || p.includes('financial') || p.includes('cost')) {
    return {
      id: `ai-${Date.now()}`,
      sender: 'assistant',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      text: 'TOP VALUE RECOVERED: ?2.84 LAKHS TOTAL THIS CYCLE.',
      structuredDetails: {
        title: 'Financial Savings Attribution',
        stats: [
          { label: '01 Furniture & Asset Reallocation', value: '?1.24 L (120 seminar chairs diverted)', color: 'text-emerald-400' },
          { label: '02 Food Surplus Redistribution', value: '?94,200 (6,840 kg meals redirected)', color: 'text-emerald-400' },
          { label: '03 Rainwater Substitution', value: '?42,800 (184,200 L harvested vs municipal)', color: 'text-cyan-400' },
          { label: '04 Chiller Setpoint Optimization', value: '?22,800 in avoided peak tariffs', color: 'text-amber-400' },
        ],
        causes: [
          'Proactive matchmaking captured 91% of decommissioned assets before municipal disposal contracts were initiated.',
        ],
        actions: [
          { label: 'Download Executive ESG & ROI Audit Report', route: '/impact', actionType: 'view_impact' },
        ],
      },
    };
  }

  // 7. Today's biggest inefficiency / General query
  return {
    id: `ai-${Date.now()}`,
    sender: 'assistant',
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    text: 'BIGGEST CURRENT INEFFICIENCY: BLOCK B UNNOTICED WATER DRAW.',
    structuredDetails: {
      title: 'Real-Time Campus Diagnostics',
      stats: [
        { label: 'Identified Node', value: 'Block B Sciences Manifold W-04', color: 'text-rose-400' },
        { label: 'Excess Rate', value: '+18.4% above normal idle flow', color: 'text-rose-400' },
        { label: 'Direct Impact', value: '2,400 � 3,100 L/day avoidable loss', color: 'text-amber-400' },
        { label: 'Secondary Hotspot', value: 'Cafeteria A 55 kg food surplus expiring in 3.2h', color: 'text-amber-400' },
      ],
      causes: [
        'Nighttime telemetry showed flat high-volume draw without diurnal decay.',
        'Cafeteria A production batch was calculated using stale attendance baseline.',
      ],
      actions: [
        { label: 'Execute Action: Inspect Block B', route: '/alerts', actionType: 'inspect_block_b' },
        { label: 'Launch Surplus Matchmaker', route: '/matches', actionType: 'launch_matchmaker' },
      ],
    },
  };
}
