import React, { useState } from 'react';
import { useResource } from '../context/ResourceContext';
import {
  FileText,
  Download,
  Calendar,
  CheckCircle,
  Clock,
  Printer,
  Share2,
  ShieldCheck,
  FileSpreadsheet
} from 'lucide-react';

export const ReportsPage: React.FC = () => {
  const { impactMetrics } = useResource();
  const [generatedSuccess, setGeneratedSuccess] = useState<string | null>(null);

  const reports = [
    {
      id: 'REP-2026-Q3',
      title: 'Quarterly Campus ESG Compliance & Circularity Audit',
      date: 'Generated Oct 08, 2026',
      size: '2.4 MB',
      type: 'Executive PDF',
      status: 'VERIFIED',
    },
    {
      id: 'REP-WTR-09',
      title: 'Monthly Nocturnal Water Loss & Acoustic Leak Detection Log',
      date: 'Generated Oct 01, 2026',
      size: '1.1 MB',
      type: 'Technical CSV',
      status: 'VERIFIED',
    },
    {
      id: 'REP-FOD-04',
      title: 'Dining Halls Overproduction & Dual-Split Allocation Ledger',
      date: 'Generated Sep 28, 2026',
      size: '890 KB',
      type: 'Audit Ledger',
      status: 'VERIFIED',
    },
    {
      id: 'REP-ENR-02',
      title: 'Chiller Setpoint Tariff Optimization & Solar Displacement',
      date: 'Generated Sep 15, 2026',
      size: '1.8 MB',
      type: 'Engineering Brief',
      status: 'ARCHIVED',
    },
  ];

  const handleDownload = (title: string) => {
    setGeneratedSuccess(title);
    setTimeout(() => setGeneratedSuccess(null), 3500);
  };

  return (
    <div className="min-h-screen bg-[#080c14] text-slate-100 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-indigo-400 animate-pulse" />
            <span className="text-xs font-mono uppercase tracking-widest text-indigo-400 font-bold">
              REGULATORY & COMPLIANCE ARCHIVE
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
            REPORT CENTER
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 font-mono mt-0.5">
            Cryptographically signed sustainability briefs � Automated compliance filings � Audit ledgers
          </p>
        </div>

        <button
          onClick={() => handleDownload('Campus Comprehensive Sustainability Dossier')}
          className="px-4 py-2 text-xs font-bold bg-emerald-400 hover:bg-emerald-300 text-slate-950 rounded-xl transition shadow-lg shadow-emerald-500/20 flex items-center gap-2"
        >
          <FileText className="w-4 h-4" />
          <span>Generate New Audit Brief</span>
        </button>
      </div>

      {generatedSuccess && (
        <div className="p-4 bg-emerald-950/40 border border-emerald-500/40 rounded-xl text-xs font-mono text-emerald-300 flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-400" />
            <span>Successfully generated and downloaded: <strong>{generatedSuccess}</strong></span>
          </div>
          <span className="text-slate-400">Digest SHA-256 Validated</span>
        </div>
      )}

      {/* Reports List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {reports.map(rep => (
          <div
            key={rep.id}
            className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 hover:border-slate-700 transition flex flex-col justify-between space-y-4"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-mono uppercase bg-slate-800 text-slate-400 px-2 py-0.5 rounded font-bold">
                  {rep.id} � {rep.type}
                </span>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30 font-bold">
                  {rep.status}
                </span>
              </div>
              <h3 className="text-base font-bold text-white">{rep.title}</h3>
              <p className="text-xs font-mono text-slate-400 mt-1">{rep.date} � Size: {rep.size}</p>
            </div>

            <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
              <span className="text-[11px] font-mono text-slate-500">ISO 14001 Compliant</span>
              <button
                onClick={() => handleDownload(rep.title)}
                className="px-3.5 py-1.5 text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-lg border border-slate-700 transition flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5 text-emerald-400" />
                <span>Download Report</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Automated Scheduling Card */}
      <div className="bg-slate-900/60 p-6 rounded-2xl border border-slate-800 space-y-3">
        <h3 className="text-base font-bold text-white">Automated Compliance Delivery</h3>
        <p className="text-xs text-slate-400 leading-relaxed">
          RE:SOURCE automatically compiles and cryptographically timestamps weekly circularity logs for submission to university trustees, state water regulatory boards, and campus sustainability accreditation bodies.
        </p>
        <div className="flex items-center gap-4 text-xs font-mono text-emerald-400 pt-2">
          <span>� Next automated dispatch: Monday 08:00 AM</span>
          <span>� Recipient: Vice-Chancellor Facilities Directorate</span>
        </div>
      </div>
    </div>
  );
};
