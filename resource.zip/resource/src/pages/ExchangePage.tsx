import React, { useState } from 'react';
import { useResource } from '../context/ResourceContext';
import { ResourceCategory } from '../types';
import {
  ShoppingBag,
  PlusCircle,
  Filter,
  Search,
  QrCode,
  MapPin,
  Clock,
  Leaf,
  Coins,
  CheckCircle,
  ArrowRight,
  Sparkles,
  PackageCheck
} from 'lucide-react';

interface Props {
  onOpenListModal: () => void;
  onOpenPassport: (passportId: string) => void;
  onNavigate: (route: string) => void;
}

const CATEGORIES: ('ALL' | ResourceCategory)[] = [
  'ALL',
  'Food',
  'Water',
  'Energy',
  'Furniture',
  'Electronics',
  'Paper',
  'Plastic',
  'Metal',
  'Construction materials',
  'Laboratory materials',
  'Packaging',
];

export const ExchangePage: React.FC<Props> = ({ onOpenListModal, onOpenPassport, onNavigate }) => {
  const { resourceListings, claimListing } = useResource();
  const [selectedCategory, setSelectedCategory] = useState<'ALL' | ResourceCategory>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [claimedIds, setClaimedIds] = useState<string[]>([]);

  const filteredListings = resourceListings.filter(item => {
    const matchesCat = selectedCategory === 'ALL' || item.category === selectedCategory;
    const matchesQuery =
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.source.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.id.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesQuery;
  });

  const handleClaim = (id: string) => {
    claimListing(id);
    setClaimedIds(prev => [...prev, id]);
  };

  return (
    <div className="min-h-screen bg-[#080c14] text-slate-100 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-bold">
              CIRCULAR ASSET MARKETPLACE
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
            RESOURCE EXCHANGE
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 font-mono mt-0.5">
            11 material categories � Authenticated digital passports � Internal redistribution
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenListModal}
            className="px-4 py-2 text-xs font-bold bg-emerald-400 hover:bg-emerald-300 text-slate-950 rounded-xl transition shadow-lg shadow-emerald-500/20 flex items-center gap-1.5"
          >
            <PlusCircle className="w-4 h-4" />
            <span>LIST SURPLUS RESOURCE</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800 space-y-3">
        <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search listings, IDs, locations..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 font-mono"
            />
          </div>

          <div className="text-xs font-mono text-slate-400">
            Showing <strong className="text-white">{filteredListings.length}</strong> active listings
          </div>
        </div>

        {/* 11 Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto py-1 text-xs font-mono">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded-lg border whitespace-nowrap transition ${
                selectedCategory === cat
                  ? 'bg-slate-800 text-emerald-400 border-emerald-500/40 font-bold'
                  : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Resource Listings Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredListings.map(item => {
          const isClaimed = claimedIds.includes(item.id) || item.status === 'ALLOCATED' || item.status === 'MATCHED';

          return (
            <div
              key={item.id}
              className="bg-slate-900/70 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition flex flex-col justify-between space-y-4"
            >
              <div>
                {/* Top badges */}
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono uppercase bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-bold">
                      {item.category}
                    </span>
                    <span className="text-[10px] font-mono text-slate-500">{item.id}</span>
                  </div>

                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                      item.priority === 'CRITICAL'
                        ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                        : item.priority === 'HIGH'
                        ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {item.priority}
                  </span>
                </div>

                <h3 className="text-base font-bold text-white leading-snug">{item.title}</h3>

                {/* Specs */}
                <div className="space-y-1.5 mt-3 text-xs font-mono text-slate-400">
                  <div className="flex items-center justify-between">
                    <span>Quantity:</span>
                    <strong className="text-white font-bold">{item.quantity} {item.unit}</strong>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Condition:</span>
                    <span className="text-slate-300">{item.condition}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Origin:</span>
                    <span className="text-slate-300">{item.source}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Availability:</span>
                    <span className="text-cyan-400">{item.availableUntil}</span>
                  </div>
                </div>

                {/* Values & Carbon Impact */}
                <div className="grid grid-cols-2 gap-2 mt-4 p-2.5 bg-slate-950/70 rounded-xl border border-slate-800 text-xs font-mono">
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase block">Est. Value</span>
                    <strong className="text-emerald-400 font-bold">
                      ?{item.estimatedValueInr.toLocaleString()}
                    </strong>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase block">CO2 Avoided</span>
                    <strong className="text-teal-400 font-bold">{item.co2AvoidedKg} kg</strong>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-800/80 flex items-center gap-2">
                {item.passportId && (
                  <button
                    onClick={() => onOpenPassport(item.passportId)}
                    className="p-2 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 transition"
                    title="View Digital Passport"
                  >
                    <QrCode className="w-4 h-4 text-emerald-400" />
                  </button>
                )}

                {item.category === 'Food' ? (
                  <button
                    onClick={() => onNavigate('/matches')}
                    className="flex-1 py-2 px-3 text-xs font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-xl transition flex items-center justify-center gap-1.5"
                  >
                    <span>Run AI Match</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                ) : (
                  <button
                    onClick={() => handleClaim(item.id)}
                    disabled={isClaimed}
                    className={`flex-1 py-2 px-3 text-xs font-bold rounded-xl transition ${
                      isClaimed
                        ? 'bg-slate-800 text-emerald-400 border border-emerald-500/40 cursor-default'
                        : 'bg-emerald-400 hover:bg-emerald-300 text-slate-950 shadow-md'
                    }`}
                  >
                    {isClaimed ? '? Claim Initiated' : 'Request Allocation'}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
