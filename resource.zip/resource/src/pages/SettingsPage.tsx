import React, { useState } from 'react';
import { useResource } from '../context/ResourceContext';
import {
  Settings,
  Radio,
  Sliders,
  Bell,
  Shield,
  RotateCcw,
  CheckCircle,
  Building,
  Save
} from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const { isSimulating, toggleSimulation } = useResource();
  const [campusName, setCampusName] = useState('Apex University Main Campus');
  const [sensitivity, setSensitivity] = useState(15);
  const [samplingSec, setSamplingSec] = useState('3.5');
  const [autoMatchEnabled, setAutoMatchEnabled] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = () => {
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="min-h-screen bg-[#080c14] text-slate-100 p-4 sm:p-6 lg:p-8 max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-slate-400" />
            <span className="text-xs font-mono uppercase tracking-widest text-slate-400 font-bold">
              SYSTEM CONFIGURATION
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
            CONTROL CENTER SETTINGS
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 font-mono mt-0.5">
            Campus profile � IoT sensor polling rates � Anomaly heuristics � Automated match rules
          </p>
        </div>

        <button
          onClick={handleSave}
          className="px-5 py-2 text-xs font-bold bg-emerald-400 hover:bg-emerald-300 text-slate-950 rounded-xl transition shadow-lg shadow-emerald-500/20 flex items-center gap-1.5"
        >
          <Save className="w-4 h-4" />
          <span>{savedSuccess ? '? Settings Saved' : 'Save Changes'}</span>
        </button>
      </div>

      <div className="space-y-6">
        {/* Campus Profile */}
        <div className="bg-slate-900/80 p-6 rounded-2xl border border-slate-800 space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Building className="w-4 h-4 text-emerald-400" />
            Campus Organization Profile
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-mono uppercase text-slate-400 mb-1">
                Institution Name
              </label>
              <input
                type="text"
                value={campusName}
                onChange={e => setCampusName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-mono uppercase text-slate-400 mb-1">
                Total Covered Facilities
              </label>
              <input
                type="text"
                disabled
                value="16 Connected Facilities (5 Academic, 3 Cafeterias, 4 Hostels, 2 Labs, 1 Warehouse, 1 Waste Plant)"
                className="w-full bg-slate-950/60 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-400"
              />
            </div>
          </div>
        </div>

        {/* Telemetry Sampling */}
        <div className="bg-slate-900/80 p-6 rounded-2xl border border-slate-800 space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Radio className="w-4 h-4 text-cyan-400" />
            IoT Telemetry Engine Polling
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-mono uppercase text-slate-400 mb-1">
                Sensor Polling Frequency
              </label>
              <select
                value={samplingSec}
                onChange={e => setSamplingSec(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
              >
                <option value="1.0">1.0s (Real-Time Burst Mode)</option>
                <option value="3.5">3.5s (Standard Active Mode)</option>
                <option value="10.0">10.0s (Economy Bandwidth)</option>
                <option value="60.0">60.0s (Nocturnal Archive)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-slate-400 mb-1">
                Telemetry State
              </label>
              <button
                onClick={toggleSimulation}
                className={`w-full py-2 px-4 rounded-xl border text-xs font-mono font-bold transition flex items-center justify-between ${
                  isSimulating
                    ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                    : 'bg-slate-950 text-slate-400 border-slate-800'
                }`}
              >
                <span>{isSimulating ? 'IoT Stream Live & Ticking' : 'IoT Stream Paused'}</span>
                <span className="underline">Toggle</span>
              </button>
            </div>
          </div>
        </div>

        {/* Anomaly Detection Sensitivity */}
        <div className="bg-slate-900/80 p-6 rounded-2xl border border-slate-800 space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Sliders className="w-4 h-4 text-amber-400" />
            Anomaly Detection Sensitivity
          </h3>

          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-slate-300">Baseline Variance Trigger Threshold:</span>
              <strong className="text-amber-400">�{sensitivity}% deviation</strong>
            </div>
            <input
              type="range"
              min="5"
              max="35"
              value={sensitivity}
              onChange={e => setSensitivity(Number(e.target.value))}
              className="w-full accent-amber-500 bg-slate-800 h-2 rounded-lg"
            />
            <span className="text-[10px] text-slate-400 font-mono block">
              Lower percentages trigger alerts on smaller leaks; higher values prevent false positives.
            </span>
          </div>

          <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-white block">Autonomous Match Auto-Dispatch</span>
              <span className="text-[10px] text-slate-400 font-mono">Auto-approve matches with score &ge; 95 without human touch</span>
            </div>
            <button
              onClick={() => setAutoMatchEnabled(!autoMatchEnabled)}
              className={`w-11 h-6 rounded-full transition-colors p-1 ${
                autoMatchEnabled ? 'bg-emerald-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-4 h-4 rounded-full bg-white transition-transform ${
                  autoMatchEnabled ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
