import React, { useState } from 'react';
import { useResource } from '../context/ResourceContext';
import {
  Award,
  Droplets,
  Zap,
  Utensils,
  Package,
  Trash2,
  TrendingUp,
  Download,
  Calendar,
  Leaf,
  Coins,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';

export const ImpactPage: React.FC = () => {
  const { impactMetrics } = useResource();
  const [activeTab, setActiveTab] = useState<'METRICS' | 'BEFORE_AFTER' | 'ESG'>('METRICS');
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  const handleDownload = () => {
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  return (
    <div className="min-h-screen bg-[#080c14] text-slate-100 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-teal-400 animate-pulse" />
            <span className="text-xs font-mono uppercase tracking-widest text-teal-400 font-bold">
              EXECUTIVE ESG & SUSTAINABILITY
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
            IMPACT ANALYTICS
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 font-mono mt-0.5">
            Verified circular savings � GHG mitigation � Avoided municipal tariffs � ESG compliance ledger
          </p>
        </div>

        {/* Export Button */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleDownload}
            className="px-4 py-2 text-xs font-bold bg-slate-900 hover:bg-slate-800 text-teal-300 border border-slate-700 rounded-xl transition flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            <span>{downloadSuccess ? '? CSV Audit Ledger Exported' : 'Export Verified ESG Audit (.CSV)'}</span>
          </button>
        </div>
      </div>

      {/* Primary KPI Grid (Section 18) */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
          <div className="flex items-center gap-1.5 text-cyan-400 text-[10px] font-mono uppercase font-bold">
            <Droplets className="w-3.5 h-3.5" /> Water Saved
          </div>
          <div className="text-xl font-mono font-extrabold text-white mt-1">
            {impactMetrics.waterSavedLiters.toLocaleString()}
          </div>
          <span className="text-[10px] text-slate-400 font-mono">Liters</span>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
          <div className="flex items-center gap-1.5 text-amber-400 text-[10px] font-mono uppercase font-bold">
            <Zap className="w-3.5 h-3.5" /> Energy Saved
          </div>
          <div className="text-xl font-mono font-extrabold text-white mt-1">
            {impactMetrics.energySavedKwh.toLocaleString()}
          </div>
          <span className="text-[10px] text-slate-400 font-mono">kWh</span>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
          <div className="flex items-center gap-1.5 text-emerald-400 text-[10px] font-mono uppercase font-bold">
            <Utensils className="w-3.5 h-3.5" /> Food Redirected
          </div>
          <div className="text-xl font-mono font-extrabold text-white mt-1">
            {impactMetrics.foodRedirectedKg.toLocaleString()}
          </div>
          <span className="text-[10px] text-slate-400 font-mono">kg</span>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
          <div className="flex items-center gap-1.5 text-teal-400 text-[10px] font-mono uppercase font-bold">
            <Package className="w-3.5 h-3.5" /> Materials Reused
          </div>
          <div className="text-xl font-mono font-extrabold text-white mt-1">
            {impactMetrics.materialsReusedKg.toLocaleString()}
          </div>
          <span className="text-[10px] text-slate-400 font-mono">kg</span>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
          <div className="flex items-center gap-1.5 text-rose-400 text-[10px] font-mono uppercase font-bold">
            <Trash2 className="w-3.5 h-3.5" /> Waste Diverted
          </div>
          <div className="text-xl font-mono font-extrabold text-white mt-1">
            {impactMetrics.wastePreventedKg.toLocaleString()}
          </div>
          <span className="text-[10px] text-slate-400 font-mono">kg</span>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
          <div className="flex items-center gap-1.5 text-emerald-300 text-[10px] font-mono uppercase font-bold">
            <Coins className="w-3.5 h-3.5" /> Cost Saved
          </div>
          <div className="text-xl font-mono font-extrabold text-emerald-400 mt-1">
            ?{(impactMetrics.costRecoveredInr / 100000).toFixed(2)} L
          </div>
          <span className="text-[10px] text-slate-400 font-mono">Rupees</span>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
          <div className="flex items-center gap-1.5 text-teal-300 text-[10px] font-mono uppercase font-bold">
            <Leaf className="w-3.5 h-3.5" /> CO2 Avoided
          </div>
          <div className="text-xl font-mono font-extrabold text-teal-300 mt-1">
            {impactMetrics.co2AvoidedTonnes.toFixed(1)}
          </div>
          <span className="text-[10px] text-slate-400 font-mono">Tonnes</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 text-xs font-mono">
        <button
          onClick={() => setActiveTab('METRICS')}
          className={`px-3 py-1.5 rounded-lg transition ${
            activeTab === 'METRICS'
              ? 'bg-slate-800 text-teal-400 font-bold border border-slate-700'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Performance Attribution
        </button>
        <button
          onClick={() => setActiveTab('BEFORE_AFTER')}
          className={`px-3 py-1.5 rounded-lg transition ${
            activeTab === 'BEFORE_AFTER'
              ? 'bg-slate-800 text-teal-400 font-bold border border-slate-700'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Before vs After Adoption
        </button>
        <button
          onClick={() => setActiveTab('ESG')}
          className={`px-3 py-1.5 rounded-lg transition ${
            activeTab === 'ESG'
              ? 'bg-slate-800 text-teal-400 font-bold border border-slate-700'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          ESG & UN SDG Alignment
        </button>
      </div>

      {/* Tab 1: Performance Attribution */}
      {activeTab === 'METRICS' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-slate-900/70 p-6 rounded-2xl border border-slate-800 space-y-4">
            <h3 className="text-base font-bold text-white">Monthly Cost Recovery Trends</h3>
            <div className="space-y-3 text-xs font-mono">
              <div>
                <div className="flex justify-between mb-1">
                  <span>Decommissioned Furniture Reallocation</span>
                  <span className="text-emerald-400 font-bold">?1,24,000 (43.6%)</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div className="bg-emerald-400 h-full rounded-full" style={{ width: '43.6%' }} />
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>Food Surplus Redistribution</span>
                  <span className="text-cyan-400 font-bold">?94,200 (33.1%)</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div className="bg-cyan-400 h-full rounded-full" style={{ width: '33.1%' }} />
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>Rainwater Cistern Harvesting</span>
                  <span className="text-teal-400 font-bold">?42,800 (15.1%)</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div className="bg-teal-400 h-full rounded-full" style={{ width: '15.1%' }} />
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>HVAC Setpoint Off-Peak Tariffs</span>
                  <span className="text-amber-400 font-bold">?23,000 (8.2%)</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div className="bg-amber-400 h-full rounded-full" style={{ width: '8.2%' }} />
                </div>
              </div>
            </div>
          </div>

          <div className="bg-slate-900/70 p-6 rounded-2xl border border-slate-800 space-y-4">
            <h3 className="text-base font-bold text-white">Campus Circularity Health Index</h3>
            <p className="text-xs text-slate-400">
              Evaluates the ratio of resources kept in productive circulation versus sent to municipal landfill or incinerators.
            </p>
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-around text-center">
              <div>
                <span className="text-[10px] font-mono text-slate-400 uppercase block">Circularity Index</span>
                <strong className="text-3xl font-mono font-extrabold text-emerald-400">89.2%</strong>
              </div>
              <div className="h-10 w-px bg-slate-800" />
              <div>
                <span className="text-[10px] font-mono text-slate-400 uppercase block">Response Velocity</span>
                <strong className="text-3xl font-mono font-extrabold text-cyan-400">14 min</strong>
              </div>
              <div className="h-10 w-px bg-slate-800" />
              <div>
                <span className="text-[10px] font-mono text-slate-400 uppercase block">Leak Containment</span>
                <strong className="text-3xl font-mono font-extrabold text-teal-400">&lt; 3 hrs</strong>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Before vs After Adoption */}
      {activeTab === 'BEFORE_AFTER' && (
        <div className="bg-slate-900/70 p-6 rounded-2xl border border-slate-800 space-y-6">
          <h3 className="text-base font-bold text-white">Before vs After RE:SOURCE Deployment</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs font-mono">
            {/* Before */}
            <div className="bg-rose-950/20 p-5 rounded-xl border border-rose-500/30 space-y-3">
              <span className="text-xs font-bold text-rose-400 uppercase font-mono block">
                PRIOR STATE (FRAGMENTED LEGACY WORKFLOWS)
              </span>
              <ul className="space-y-2 text-slate-300">
                <li>� Water leaks discovered weeks later via municipal billing invoices.</li>
                <li>� Cafeterias dumped 65-80 kg cooked meals into dumpsters every evening.</li>
                <li>� Decommissioned furniture piled in basements until damaged by moisture.</li>
                <li>� Campus landfill diversion rate hovered below 42%.</li>
                <li>� Annual waste disposal fees exceeded ?18.5 Lakhs.</li>
              </ul>
            </div>

            {/* After */}
            <div className="bg-emerald-950/20 p-5 rounded-xl border border-emerald-500/30 space-y-3">
              <span className="text-xs font-bold text-emerald-400 uppercase font-mono block">
                CURRENT STATE (AUTONOMOUS RE:SOURCE OS)
              </span>
              <ul className="space-y-2 text-slate-200">
                <li>� Acoustic leak detection isolates manifold cracks in &lt; 15 minutes.</li>
                <li>� 55 kg food surplus dual-matched and dispatched in 14 minutes.</li>
                <li>� Digital passports track and reuse 94% of office furniture assets.</li>
                <li>� Landfill diversion rate increased to 89.2%.</li>
                <li>� Net economic recovery: ?2.84 Lakhs saved this cycle alone.</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: ESG & SDG */}
      {activeTab === 'ESG' && (
        <div className="bg-slate-900/70 p-6 rounded-2xl border border-slate-800 space-y-4">
          <h3 className="text-base font-bold text-white">United Nations Sustainable Development Goals (SDG)</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
              <span className="text-amber-400 font-bold block mb-1">SDG 12: Responsible Consumption</span>
              <p className="text-slate-400">
                12,482 kg waste diverted and 89% campus circularity score through predictive prep and instant matching.
              </p>
            </div>
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
              <span className="text-cyan-400 font-bold block mb-1">SDG 6: Clean Water & Sanitation</span>
              <p className="text-slate-400">
                184,200 Liters protected through nocturnal acoustic anomaly monitoring and rainwater harvesting integration.
              </p>
            </div>
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
              <span className="text-emerald-400 font-bold block mb-1">SDG 13: Climate Action</span>
              <p className="text-slate-400">
                4.7 tonnes of CO2 equivalent avoided from entering atmosphere through methane-heavy landfill decomposition.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
