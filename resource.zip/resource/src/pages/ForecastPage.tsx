import React, { useState } from 'react';
import { generateForecast } from '../services/predictionEngine';
import {
  TrendingUp,
  Sliders,
  Calendar,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  RotateCcw,
  Utensils,
  Droplets,
  Zap
} from 'lucide-react';

interface Props {
  onNavigate: (route: string) => void;
}

export const ForecastPage: React.FC<Props> = ({ onNavigate }) => {
  const [selectedCategory, setSelectedCategory] = useState<'Food' | 'Water' | 'Energy'>('Food');
  const [eventAttendanceBoost, setEventAttendanceBoost] = useState<number>(0);
  const [ambientTempDelta, setAmbientTempDelta] = useState<number>(0);
  const [isExamWeek, setIsExamWeek] = useState<boolean>(false);
  const [isPlanApplied, setIsPlanApplied] = useState<boolean>(false);

  const forecast = generateForecast(selectedCategory, {
    eventAttendanceBoost,
    ambientTempDelta,
    isExamWeek,
  });

  return (
    <div className="min-h-screen bg-[#080c14] text-slate-100 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
            <span className="text-xs font-mono uppercase tracking-widest text-cyan-400 font-bold">
              BAYESIAN AI PREDICTION ENGINE
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
            RESOURCE PREDICTION CENTER
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 font-mono mt-0.5">
            Predict demand before it occurs � Identify upcoming surplus � Calculate lean production buffers
          </p>
        </div>

        {/* Category Selector */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-900 rounded-xl border border-slate-800">
          {(['Food', 'Water', 'Energy'] as const).map(cat => (
            <button
              key={cat}
              onClick={() => {
                setSelectedCategory(cat);
                setIsPlanApplied(false);
              }}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-mono font-bold transition ${
                selectedCategory === cat
                  ? 'bg-cyan-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Interactive Scenario Planner & Forecast Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Scenario Controls Left Panel */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-slate-400 font-bold">
              <Sliders className="w-4 h-4 text-cyan-400" />
              Scenario Simulation Parameters
            </div>
            <p className="text-xs text-slate-400">
              Adjust external campus factors to simulate real-time forecast curve shifts.
            </p>

            {/* Event Attendance Boost Slider */}
            <div className="space-y-1.5 pt-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-300">Campus Event Attendance:</span>
                <span className="text-emerald-400 font-bold">+{eventAttendanceBoost} attendees</span>
              </div>
              <input
                type="range"
                min="0"
                max="2500"
                step="100"
                value={eventAttendanceBoost}
                onChange={e => {
                  setEventAttendanceBoost(Number(e.target.value));
                  setIsPlanApplied(false);
                }}
                className="w-full accent-emerald-500 bg-slate-800 h-2 rounded-lg"
              />
              <span className="text-[10px] text-slate-500 font-mono">Simulates symposiums, sports fests, hackathons</span>
            </div>

            {/* Ambient Temperature Delta */}
            <div className="space-y-1.5 pt-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-300">Ambient Temp Variance:</span>
                <span className="text-amber-400 font-bold">
                  {ambientTempDelta > 0 ? `+${ambientTempDelta}�C` : `${ambientTempDelta}�C`}
                </span>
              </div>
              <input
                type="range"
                min="-5"
                max="8"
                step="1"
                value={ambientTempDelta}
                onChange={e => {
                  setAmbientTempDelta(Number(e.target.value));
                  setIsPlanApplied(false);
                }}
                className="w-full accent-amber-500 bg-slate-800 h-2 rounded-lg"
              />
              <span className="text-[10px] text-slate-500 font-mono">Drives HVAC cooling load and water consumption</span>
            </div>

            {/* Exam Week Toggle */}
            <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-white block">Student Exam Week Mode</span>
                <span className="text-[10px] text-slate-400 font-mono">Higher night library load, skipped cafeteria meals</span>
              </div>
              <button
                onClick={() => {
                  setIsExamWeek(!isExamWeek);
                  setIsPlanApplied(false);
                }}
                className={`w-11 h-6 rounded-full transition-colors p-1 ${
                  isExamWeek ? 'bg-cyan-500' : 'bg-slate-800'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-white transition-transform ${
                    isExamWeek ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Reset Defaults */}
            <button
              onClick={() => {
                setEventAttendanceBoost(0);
                setAmbientTempDelta(0);
                setIsExamWeek(false);
                setIsPlanApplied(false);
              }}
              className="w-full py-2 text-xs font-mono text-slate-400 hover:text-white bg-slate-950 rounded-lg border border-slate-800 transition flex items-center justify-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset to Neutral Baseline</span>
            </button>
          </div>
        </div>

        {/* Forecast Output Right Panel */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-slate-900/80 p-6 rounded-2xl border border-slate-800 space-y-6">
            {/* KPI Row (Today vs Tomorrow vs Predicted Surplus vs Confidence) */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                <span className="text-[10px] font-mono uppercase text-slate-400 block">Today's Total</span>
                <div className="text-xl font-bold font-mono text-white mt-1">
                  {forecast.todayValue.toLocaleString()} {forecast.unit}
                </div>
              </div>

              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                <span className="text-[10px] font-mono uppercase text-slate-400 block">Predicted Demand (T+1)</span>
                <div className="text-xl font-bold font-mono text-cyan-300 mt-1">
                  {forecast.tomorrowValue.toLocaleString()} {forecast.unit}
                </div>
              </div>

              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                <span className="text-[10px] font-mono uppercase text-slate-400 block">Predicted Surplus</span>
                <div className="text-xl font-bold font-mono text-amber-400 mt-1">
                  {forecast.predictedSurplus} {forecast.unit}
                </div>
              </div>

              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                <span className="text-[10px] font-mono uppercase text-slate-400 block">AI Confidence</span>
                <div className="text-xl font-bold font-mono text-emerald-400 mt-1">
                  {forecast.confidencePercentage}%
                </div>
              </div>
            </div>

            {/* 7-Day Prediction Chart Curve with Bounds */}
            <div className="space-y-2">
              <div className="text-xs font-mono uppercase text-slate-400 font-bold flex items-center justify-between">
                <span>7-Day Predictive Horizon with 95% Confidence Interval</span>
                <span className="text-emerald-400 font-bold">Bayesian Regressor</span>
              </div>

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-end gap-3 h-52 overflow-x-auto">
                {forecast.chartData.map((pt, idx) => {
                  const maxVal = Math.max(...forecast.chartData.map(c => c.upperBound));
                  const predH = (pt.predicted / maxVal) * 100;
                  const upperH = (pt.upperBound / maxVal) * 100;
                  const isFuture = idx >= 4;

                  return (
                    <div key={idx} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end min-w-[42px]">
                      <div className="w-full flex items-end justify-center relative h-38">
                        {/* Upper bound ghost outline */}
                        <div
                          style={{ height: `${upperH}%` }}
                          className={`w-7 rounded-t border-t border-dashed ${
                            isFuture ? 'border-cyan-400/50 bg-cyan-500/5' : 'border-slate-700 bg-slate-800/10'
                          } absolute bottom-0`}
                        />
                        {/* Primary bar */}
                        <div
                          style={{ height: `${predH}%` }}
                          className={`w-4 rounded-t z-10 transition-all ${
                            isFuture
                              ? 'bg-gradient-to-t from-cyan-600 to-cyan-400 shadow-[0_0_10px_rgba(6,182,212,0.5)]'
                              : 'bg-slate-600'
                          }`}
                        />
                      </div>
                      <div className="text-center">
                        <span className={`text-[10px] font-mono block ${isFuture ? 'text-cyan-300 font-bold' : 'text-slate-400'}`}>
                          {pt.time}
                        </span>
                        <span className="text-[9px] font-mono text-slate-500">{pt.predicted}</span>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="flex items-center gap-4 text-xs font-mono text-slate-400 pt-1 justify-end">
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 bg-slate-600 rounded-sm" /> Historical Actual
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 bg-cyan-400 rounded-sm" /> AI Forecast (Tomorrow+)
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 border border-dashed border-cyan-400/60 rounded-sm" /> 95% Confidence Band
                </div>
              </div>
            </div>

            {/* AI Recommendation Box */}
            <div className="bg-emerald-950/20 p-5 rounded-xl border border-emerald-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-[10px] font-mono uppercase bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded font-bold border border-emerald-500/30">
                  OPTIMAL LEAN RECOMMENDATION
                </span>
                <h3 className="text-base font-bold text-white mt-1">
                  Target Production: <span className="text-emerald-300">{forecast.recommendedProduction} {forecast.unit}</span>
                </h3>
                <p className="text-xs text-slate-300 mt-0.5">
                  Preemptively reducing tomorrow's preparation prevents approx.{' '}
                  <strong className="text-white">{forecast.predictedSurplus} {forecast.unit}</strong> of perishable waste.
                </p>
              </div>

              <button
                onClick={() => setIsPlanApplied(true)}
                disabled={isPlanApplied}
                className={`px-5 py-3 rounded-xl font-bold text-xs tracking-wider transition ${
                  isPlanApplied
                    ? 'bg-slate-800 text-emerald-400 border border-emerald-500/40 cursor-default'
                    : 'bg-emerald-400 hover:bg-emerald-300 text-slate-950 shadow-lg shadow-emerald-500/20 active:scale-95'
                }`}
              >
                {isPlanApplied ? '? Plan Transmitted to Kitchen BMS' : 'Apply Lean Production Target'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
