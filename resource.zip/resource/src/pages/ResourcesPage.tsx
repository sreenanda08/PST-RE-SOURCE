import React, { useState } from 'react';
import { useResource } from '../context/ResourceContext';
import {
  Layers,
  Droplets,
  Zap,
  Utensils,
  Package,
  Trash2,
  Activity,
  AlertTriangle,
  ChevronRight,
  TrendingUp,
  TrendingDown,
  Building2,
  Sliders,
  Filter
} from 'lucide-react';

interface Props {
  onNavigate: (route: string) => void;
  onInspectAlert: (alertId: string) => void;
}

export const ResourcesPage: React.FC<Props> = ({ onNavigate, onInspectAlert }) => {
  const { telemetry, facilities } = useResource();
  const [selectedStream, setSelectedStream] = useState<string>('WATER');
  const [facilityFilter, setFacilityFilter] = useState<string>('ALL');

  const activeStreamData = telemetry.find(t => t.type === selectedStream) || telemetry[0];

  const filteredFacilities = facilities.filter(f => {
    if (facilityFilter === 'ALL') return true;
    return f.type === facilityFilter;
  });

  return (
    <div className="min-h-screen bg-[#080c14] text-slate-100 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-bold">
              CAMPUS RESOURCE INTELLIGENCE
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
            FACILITY TELEMETRY & SUB-METERING
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 font-mono mt-0.5">
            Real-time sensor arrays across 16 campus facilities � Hourly consumption curves � Anomaly isolation
          </p>
        </div>

        {/* Stream Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto p-1 bg-slate-900 rounded-xl border border-slate-800">
          {telemetry.map(t => (
            <button
              key={t.type}
              onClick={() => setSelectedStream(t.type)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition flex items-center gap-1.5 ${
                selectedStream === t.type
                  ? 'bg-emerald-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>{t.type}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Selected Stream Deep-Dive Banner */}
      <div className="bg-slate-900/80 p-6 rounded-2xl border border-slate-800 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono uppercase bg-slate-800 text-slate-300 px-2 py-0.5 rounded">
                ACTIVE TELEMETRY STREAM
              </span>
              <span
                className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                  activeStreamData.status === 'CRITICAL'
                    ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                    : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                }`}
              >
                STATUS: {activeStreamData.status}
              </span>
            </div>
            <h2 className="text-xl font-bold text-white mt-1">{activeStreamData.name}</h2>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              Current: <strong className="text-white">{activeStreamData.currentValue.toLocaleString()} {activeStreamData.unit}</strong> � Baseline: {activeStreamData.baselineValue.toLocaleString()} ({activeStreamData.trendPercentage > 0 ? `+${activeStreamData.trendPercentage}%` : `${activeStreamData.trendPercentage}%`})
            </p>
          </div>

          <div className="flex items-center gap-4 bg-slate-950 p-3 rounded-xl border border-slate-800">
            <div className="text-right">
              <div className="text-[10px] font-mono text-slate-400 uppercase">Stream Efficiency</div>
              <div className="text-2xl font-mono font-extrabold text-emerald-400">
                {activeStreamData.efficiencyScore}/100
              </div>
            </div>
          </div>
        </div>

        {/* Hourly Trend Bar Chart Visualization */}
        <div className="space-y-2">
          <div className="text-xs font-mono uppercase text-slate-400 font-bold flex items-center justify-between">
            <span>24-Hour Diurnal Telemetry Curve (Actual vs Baseline)</span>
            <span className="text-slate-400">Unit: {activeStreamData.unit.split(' ')[0]}</span>
          </div>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-end gap-2 h-48 overflow-x-auto">
            {activeStreamData.hourlyCurve.map((pt, idx) => {
              const maxVal = Math.max(...activeStreamData.hourlyCurve.map(c => Math.max(c.actual, c.baseline)));
              const actualH = (pt.actual / maxVal) * 100;
              const baselineH = (pt.baseline / maxVal) * 100;
              const isOver = pt.actual > pt.baseline * 1.15;

              return (
                <div key={idx} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end min-w-[36px]">
                  <div className="w-full flex items-end justify-center gap-1 h-36">
                    {/* Baseline bar (gray) */}
                    <div
                      style={{ height: `${baselineH}%` }}
                      className="w-2.5 bg-slate-700/60 rounded-t-sm"
                      title={`Baseline: ${pt.baseline}`}
                    />
                    {/* Actual bar (colored) */}
                    <div
                      style={{ height: `${actualH}%` }}
                      className={`w-3.5 rounded-t-sm transition-all ${
                        isOver
                          ? 'bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.6)]'
                          : 'bg-emerald-400'
                      }`}
                      title={`Actual: ${pt.actual}`}
                    />
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">{pt.hour}</span>
                </div>
              );
            })}
          </div>

          <div className="flex items-center gap-4 text-xs font-mono text-slate-400 pt-1 justify-end">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 bg-slate-700 rounded-sm" /> Baseline
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 bg-emerald-400 rounded-sm" /> Normal Actual
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 bg-rose-500 rounded-sm" /> Anomaly Spike (&gt;15%)
            </div>
          </div>
        </div>
      </div>

      {/* Facility Grid Breakdown */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold text-white">Campus Facilities Breakdown ({facilities.length})</h2>
            <p className="text-xs text-slate-400 font-mono">
              Sensory feed per building: Academic, Cafeterias, Hostels, Labs, Logistics
            </p>
          </div>

          {/* Type Filter */}
          <div className="flex items-center gap-1.5 overflow-x-auto text-xs font-mono">
            {['ALL', 'ACADEMIC', 'CAFETERIA', 'HOSTEL', 'LAB', 'WAREHOUSE'].map(type => (
              <button
                key={type}
                onClick={() => setFacilityFilter(type)}
                className={`px-2.5 py-1 rounded-lg border transition ${
                  facilityFilter === type
                    ? 'bg-slate-800 text-emerald-400 border-emerald-500/40 font-bold'
                    : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredFacilities.map(fac => (
            <div
              key={fac.id}
              className={`p-4 rounded-xl border transition ${
                fac.status === 'critical'
                  ? 'bg-rose-950/20 border-rose-500/40 hover:border-rose-500/60'
                  : fac.status === 'warning'
                  ? 'bg-amber-950/20 border-amber-500/40 hover:border-amber-500/60'
                  : fac.status === 'surplus'
                  ? 'bg-emerald-950/20 border-emerald-500/40 hover:border-emerald-500/60'
                  : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] font-mono uppercase bg-slate-800/80 text-slate-400 px-2 py-0.5 rounded">
                    {fac.code} � {fac.type}
                  </span>
                  <h3 className="text-sm font-bold text-white mt-1.5">{fac.name}</h3>
                </div>

                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold uppercase ${
                    fac.status === 'critical'
                      ? 'bg-rose-500/20 text-rose-400 animate-pulse'
                      : fac.status === 'warning'
                      ? 'bg-amber-500/20 text-amber-400'
                      : fac.status === 'surplus'
                      ? 'bg-emerald-500/20 text-emerald-400'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {fac.status}
                </span>
              </div>

              {/* Consumption numbers */}
              <div className="grid grid-cols-2 gap-2 mt-4 text-xs font-mono bg-slate-950/60 p-2.5 rounded-lg border border-slate-800/80">
                <div>
                  <span className="text-slate-400 text-[10px] block">Water Draw</span>
                  <strong className="text-white">{fac.currentConsumption.waterL.toLocaleString()} L</strong>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">Energy Load</span>
                  <strong className="text-white">{fac.currentConsumption.energyKwh} kWh</strong>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">Food Prepared</span>
                  <strong className="text-white">{fac.currentConsumption.foodKg} kg</strong>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">Waste Outflow</span>
                  <strong className="text-white">{fac.currentConsumption.wasteKg} kg</strong>
                </div>
              </div>

              {/* Sub-meters list */}
              {fac.meters.length > 0 && (
                <div className="mt-3 pt-3 border-t border-slate-800/80 space-y-1">
                  <div className="text-[10px] font-mono text-slate-400 uppercase">Active Sub-Meters:</div>
                  {fac.meters.map(m => (
                    <div
                      key={m.id}
                      className="flex items-center justify-between text-xs font-mono text-slate-300"
                    >
                      <span>{m.meterType} ({m.id})</span>
                      <span className={m.status === 'anomaly' ? 'text-rose-400 font-bold' : 'text-emerald-400'}>
                        {m.currentReading} {m.unit} {m.status === 'anomaly' && '?'}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {fac.activeAlertCount > 0 && (
                <button
                  onClick={() => onInspectAlert('alt-001')}
                  className="w-full mt-3 py-1.5 text-xs font-mono bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 rounded border border-rose-500/30 transition flex items-center justify-center gap-1 font-bold"
                >
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Inspect {fac.activeAlertCount} Active Alert</span>
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
