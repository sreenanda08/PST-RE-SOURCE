import React, { useState } from 'react';
import { useResource } from '../context/ResourceContext';
import { AlertSeverity } from '../types';
import {
  AlertOctagon,
  AlertTriangle,
  CheckCircle,
  Clock,
  UserCheck,
  ShieldAlert,
  Filter,
  Check,
  X,
  Plus
} from 'lucide-react';

interface Props {
  onResolveAlert: (alertId: string) => void;
  onNavigate: (route: string) => void;
}

export const AlertsPage: React.FC<Props> = ({ onResolveAlert, onNavigate }) => {
  const {
    alerts,
    acknowledgeAlert,
    assignAlert,
    triggerTestAnomaly,
  } = useResource();

  const [severityFilter, setSeverityFilter] = useState<'ALL' | AlertSeverity>('ALL');
  const [assigningId, setAssigningId] = useState<string | null>(null);
  const [assignedName, setAssignedName] = useState('Facilities Emergency Team');

  const filteredAlerts = alerts.filter(a => {
    if (severityFilter === 'ALL') return true;
    return a.severity === severityFilter;
  });

  const getSeverityBadge = (sev: AlertSeverity) => {
    switch (sev) {
      case 'CRITICAL':
        return 'bg-rose-500/20 text-rose-400 border-rose-500/40 animate-pulse';
      case 'HIGH':
        return 'bg-amber-500/20 text-amber-400 border-amber-500/40';
      case 'MEDIUM':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/40';
      default:
        return 'bg-cyan-500/20 text-cyan-400 border-cyan-500/40';
    }
  };

  return (
    <div className="min-h-screen bg-[#080c14] text-slate-100 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
            <span className="text-xs font-mono uppercase tracking-widest text-rose-400 font-bold">
              REAL-TIME ANOMALY TRIAGE
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
            ALERT CENTER
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 font-mono mt-0.5">
            Acknowledge � Assign staff � Dispatch corrective repairs � Resolve anomaly tickets
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-3">
          <button
            onClick={triggerTestAnomaly}
            className="px-4 py-2 text-xs font-bold bg-slate-900 hover:bg-slate-800 text-amber-300 border border-slate-700 rounded-xl transition flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4 text-amber-400" />
            <span>Simulate Live Anomaly Ingestion</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto text-xs font-mono">
        {(['ALL', 'CRITICAL', 'HIGH', 'MEDIUM', 'INFO'] as const).map(sev => (
          <button
            key={sev}
            onClick={() => setSeverityFilter(sev)}
            className={`px-3 py-1.5 rounded-xl border transition ${
              severityFilter === sev
                ? 'bg-slate-800 text-white border-slate-600 font-bold'
                : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:text-white'
            }`}
          >
            {sev} ({sev === 'ALL' ? alerts.length : alerts.filter(a => a.severity === sev).length})
          </button>
        ))}
      </div>

      {/* Alerts List */}
      <div className="space-y-4">
        {filteredAlerts.map(alert => (
          <div
            key={alert.id}
            className={`p-5 rounded-2xl border transition space-y-4 ${
              alert.status === 'RESOLVED'
                ? 'bg-slate-950/40 border-slate-900 opacity-60'
                : alert.severity === 'CRITICAL'
                ? 'bg-rose-950/20 border-rose-500/40'
                : alert.severity === 'HIGH'
                ? 'bg-amber-950/20 border-amber-500/40'
                : 'bg-slate-900/70 border-slate-800'
            }`}
          >
            {/* Top row */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold border uppercase ${getSeverityBadge(alert.severity)}`}>
                  {alert.severity}
                </span>
                <span className="text-xs font-mono text-slate-400">ID: {alert.id}</span>
                <span className="text-slate-600">�</span>
                <span className="text-xs font-mono text-slate-400">{alert.detectedAt}</span>
              </div>

              <span
                className={`text-[10px] font-mono px-2.5 py-0.5 rounded-full font-bold uppercase self-start sm:self-auto ${
                  alert.status === 'RESOLVED'
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                    : alert.status === 'ACKNOWLEDGED'
                    ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40'
                    : alert.status === 'ASSIGNED'
                    ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                    : 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                }`}
              >
                {alert.status}
              </span>
            </div>

            {/* Title & Facility */}
            <div>
              <h3 className="text-base font-bold text-white">{alert.title}</h3>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                Target Facility: <span className="text-slate-200">{alert.facility}</span> � Resource: <span className="text-slate-200">{alert.resourceType}</span> � Deviation: <span className="text-rose-400 font-bold">{alert.deviation}</span>
              </p>
            </div>

            {/* Diagnostics and Action */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-mono bg-slate-950/70 p-3 rounded-xl border border-slate-800">
              <div>
                <span className="text-slate-500 uppercase text-[10px] block">Probable Root Cause</span>
                <span className="text-slate-300">{alert.probableCause}</span>
              </div>
              <div>
                <span className="text-slate-500 uppercase text-[10px] block">Recommended Action</span>
                <span className="text-emerald-400 font-bold">{alert.recommendedAction}</span>
              </div>
            </div>

            {/* Assignee if any */}
            {alert.assignedTo && (
              <div className="text-xs font-mono text-cyan-300 flex items-center gap-1.5">
                <UserCheck className="w-3.5 h-3.5" />
                <span>Assigned to: {alert.assignedTo}</span>
              </div>
            )}

            {alert.resolutionNotes && (
              <div className="text-xs font-mono text-emerald-300 bg-emerald-950/20 p-2 rounded-lg border border-emerald-500/30">
                Resolution Notes: {alert.resolutionNotes}
              </div>
            )}

            {/* Interactive Triage Actions */}
            {alert.status !== 'RESOLVED' && (
              <div className="pt-2 flex flex-wrap items-center gap-2 border-t border-slate-800/80">
                {alert.status === 'DETECTED' && (
                  <button
                    onClick={() => acknowledgeAlert(alert.id)}
                    className="px-3 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 transition"
                  >
                    Acknowledge
                  </button>
                )}

                {assigningId === alert.id ? (
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={assignedName}
                      onChange={e => setAssignedName(e.target.value)}
                      className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white"
                    />
                    <button
                      onClick={() => {
                        assignAlert(alert.id, assignedName);
                        setAssigningId(null);
                      }}
                      className="px-2.5 py-1 text-xs bg-amber-400 text-slate-950 font-bold rounded-lg"
                    >
                      Save
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setAssigningId(alert.id)}
                    className="px-3 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 transition"
                  >
                    Assign Staff
                  </button>
                )}

                <button
                  onClick={() => onResolveAlert(alert.id)}
                  className="px-4 py-1.5 text-xs font-bold bg-emerald-400 hover:bg-emerald-300 text-slate-950 rounded-lg transition shadow-md ml-auto"
                >
                  Resolve Alert Ticket
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
