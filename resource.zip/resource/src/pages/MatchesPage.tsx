import React, { useState } from 'react';
import { useResource } from '../context/ResourceContext';
import { computeOptimalMatch } from '../services/matchingEngine';
import {
  GitCompare,
  CheckCircle,
  ArrowRight,
  Sparkles,
  MapPin,
  Clock,
  Leaf,
  Coins,
  ShieldCheck,
  Truck,
  RotateCcw,
  QrCode,
  Flame,
  FileCheck
} from 'lucide-react';

interface Props {
  onNavigate: (route: string) => void;
  onOpenPassport: (passportId: string) => void;
}

export const MatchesPage: React.FC<Props> = ({ onNavigate, onOpenPassport }) => {
  const { resourceListings, demandNodes, executeAllocation, transfers } = useResource();

  const foodSurplus = resourceListings.find(r => r.id === 'RES-00482') || resourceListings[0];
  const [selectedSurplusId, setSelectedSurplusId] = useState(foodSurplus?.id || 'RES-00482');
  const [isAllocated, setIsAllocated] = useState(foodSurplus?.status === 'ALLOCATED');

  const currentSurplus = resourceListings.find(r => r.id === selectedSurplusId) || foodSurplus;
  const matchRecommendation = currentSurplus ? computeOptimalMatch(currentSurplus, demandNodes) : null;

  const handleApprove = () => {
    if (currentSurplus) {
      executeAllocation(currentSurplus.id);
      setIsAllocated(true);
    }
  };

  return (
    <div className="min-h-screen bg-[#080c14] text-slate-100 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
            <span className="text-xs font-mono uppercase tracking-widest text-cyan-400 font-bold">
              FLAGSHIP CIRCULAR ENGINE
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
            RESOURCE MATCHING ENGINE
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 font-mono mt-0.5">
            Surplus detection ? Candidate node evaluation ? Multi-criteria optimization ? Instant dispatch
          </p>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-3 py-1.5 rounded-xl border border-emerald-500/30 font-bold">
            Algorithmic Precision: 98.4%
          </span>
        </div>
      </div>

      {/* Main Grid: Surplus Selection & Candidate Search */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Surplus Origin Card */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-mono uppercase text-slate-400 font-bold">
                DETECTED SURPLUS SOURCE
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/30 font-bold">
                SAFE WINDOW: 3.5h
              </span>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-base font-bold text-white">{currentSurplus.title}</h3>
                  <div className="text-xs font-mono text-slate-400 mt-1 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Origin: {currentSurplus.source}</span>
                  </div>
                </div>
                <span className="text-lg font-mono font-extrabold text-amber-400">
                  {currentSurplus.quantity} {currentSurplus.unit}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-2 border-t border-slate-800/80">
                <div>
                  <span className="text-slate-400">Estimated Value:</span>
                  <div className="font-bold text-white">?{currentSurplus.estimatedValueInr.toLocaleString()}</div>
                </div>
                <div>
                  <span className="text-slate-400">CO2 Avoidable:</span>
                  <div className="font-bold text-teal-400">{currentSurplus.co2AvoidedKg} kg</div>
                </div>
              </div>

              {currentSurplus.passportId && (
                <button
                  onClick={() => onOpenPassport(currentSurplus.passportId)}
                  className="w-full text-xs py-2 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white rounded-lg border border-slate-800 transition flex items-center justify-center gap-1.5 font-mono"
                >
                  <QrCode className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Inspect Digital Passport ({currentSurplus.passportId})</span>
                </button>
              )}
            </div>
          </div>

          {/* Candidate Demand Nodes Evaluated */}
          <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 space-y-3">
            <h3 className="text-xs font-mono uppercase text-slate-400 font-bold">
              CANDIDATE DEMAND NODES EVALUATED
            </h3>

            <div className="space-y-2">
              {demandNodes
                .filter(d => d.category === currentSurplus.category)
                .map(node => (
                  <div
                    key={node.id}
                    className="p-3 bg-slate-950/70 rounded-xl border border-slate-800 hover:border-slate-700 transition"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white">{node.name}</span>
                      <span
                        className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                          node.urgency === 'CRITICAL'
                            ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                            : node.urgency === 'HIGH'
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {node.urgency}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-xs text-slate-400 font-mono mt-1">
                      <span>Need: <strong className="text-white">{node.neededQuantity} {node.unit}</strong></span>
                      <span>Distance: {node.distanceKm} km</span>
                      <span>Transit: {node.transitMinutes} min</span>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>

        {/* Right Column: AI Optimal Match & Approval */}
        <div className="lg:col-span-7 space-y-4">
          {matchRecommendation ? (
            <div className="bg-slate-900/90 border border-emerald-500/40 rounded-2xl p-6 space-y-6 shadow-2xl relative overflow-hidden">
              {/* Score Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono uppercase bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded font-bold border border-emerald-500/30">
                      AI RECOMENDED ALLOCATION
                    </span>
                    <span className="text-xs font-mono text-slate-400">Match ID: {matchRecommendation.id}</span>
                  </div>
                  <h2 className="text-xl font-extrabold text-white mt-1">
                    Optimal Dual-Split Destination Routing
                  </h2>
                </div>

                <div className="flex items-center gap-3 bg-slate-950 p-2.5 rounded-xl border border-emerald-500/30">
                  <div className="text-right">
                    <div className="text-[10px] font-mono text-slate-400 uppercase">Match Score</div>
                    <div className="text-2xl font-mono font-extrabold text-emerald-400">
                      {matchRecommendation.matchScore}/100
                    </div>
                  </div>
                </div>
              </div>

              {/* Multi-Factor Scoring Weight Bar */}
              <div className="space-y-2">
                <div className="text-xs font-mono uppercase text-slate-400 font-bold flex items-center justify-between">
                  <span>Algorithmic Factor Breakdown</span>
                  <span className="text-emerald-400">Weighted Composite: Optimal</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs font-mono">
                  <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                    <span className="text-slate-400 text-[10px] uppercase block">Quantity Fit</span>
                    <span className="text-white font-bold">{matchRecommendation.factors.quantityFit}%</span>
                  </div>
                  <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                    <span className="text-slate-400 text-[10px] uppercase block">Proximity</span>
                    <span className="text-white font-bold">{matchRecommendation.factors.distanceProximity}%</span>
                  </div>
                  <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                    <span className="text-slate-400 text-[10px] uppercase block">Urgency</span>
                    <span className="text-white font-bold">{matchRecommendation.factors.urgencyPriority}%</span>
                  </div>
                  <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                    <span className="text-slate-400 text-[10px] uppercase block">Carbon Offset</span>
                    <span className="text-teal-400 font-bold">{matchRecommendation.factors.carbonOffsetEfficiency}%</span>
                  </div>
                </div>
              </div>

              {/* Dual-Split Destination Route Cards */}
              <div className="space-y-3">
                <div className="text-xs font-mono uppercase text-slate-400 font-bold">
                  Recommended Multi-Node Distribution:
                </div>

                <div className="space-y-2">
                  {matchRecommendation.destinations.map((dest, i) => (
                    <div
                      key={dest.demandId}
                      className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-mono font-bold text-xs">
                          0{i + 1}
                        </div>
                        <div>
                          <div className="text-sm font-bold text-white">{dest.destinationName}</div>
                          <div className="text-xs text-slate-400 font-mono mt-0.5">
                            Distance: {dest.distanceKm} km � Est. Transit: {dest.transitMinutes} min
                          </div>
                        </div>
                      </div>

                      <div className="text-right font-mono">
                        <div className="text-base font-extrabold text-emerald-400">
                          {dest.allocatedQuantity} {matchRecommendation.unit}
                        </div>
                        <span className="text-[10px] text-slate-400">100% Demand Met</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Total Impact Summary Pill */}
              <div className="bg-emerald-950/20 p-4 rounded-xl border border-emerald-500/30 flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-6 text-xs font-mono">
                  <div>
                    <span className="text-slate-400 block text-[10px]">TOTAL ALLOCATED</span>
                    <strong className="text-white font-bold text-sm">
                      {matchRecommendation.totalAllocated} {matchRecommendation.unit} (100%)
                    </strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">WASTE AVOIDED</span>
                    <strong className="text-emerald-400 font-bold text-sm">
                      {matchRecommendation.wasteAvoidedKg} kg
                    </strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">EST. TRANSIT</span>
                    <strong className="text-cyan-400 font-bold text-sm">
                      {matchRecommendation.estimatedTransitTimeMin} minutes
                    </strong>
                  </div>
                </div>

                <div className="text-right font-mono">
                  <span className="text-slate-400 text-[10px] block">FINANCIAL VALUE</span>
                  <span className="text-emerald-400 font-bold text-sm">
                    ?{matchRecommendation.financialSavedInr.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
                {isAllocated ? (
                  <div className="w-full p-3.5 bg-emerald-500/15 border border-emerald-500/40 rounded-xl text-center flex items-center justify-center gap-2 text-emerald-300 font-bold text-sm">
                    <CheckCircle className="w-5 h-5 text-emerald-400" />
                    <span>Resource Allocated & Dispatched (Courier EV-1 En Route)</span>
                  </div>
                ) : (
                  <button
                    onClick={handleApprove}
                    className="w-full sm:flex-1 py-4 px-6 rounded-xl bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 text-slate-950 font-bold text-sm tracking-wide shadow-xl shadow-emerald-500/20 transition active:scale-95 flex items-center justify-center gap-2"
                  >
                    <CheckCircle className="w-5 h-5" />
                    <span>APPROVE MATCH & DISPATCH RESOURCE</span>
                  </button>
                )}

                <button
                  onClick={() => onNavigate('/map')}
                  className="w-full sm:w-auto px-5 py-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs border border-slate-700 transition flex items-center justify-center gap-1.5"
                >
                  <MapPin className="w-4 h-4 text-cyan-400" />
                  <span>View on Live Map</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-slate-900/60 p-8 rounded-2xl border border-slate-800 text-center text-slate-400 font-mono">
              Select a surplus item to run the matching algorithm.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
