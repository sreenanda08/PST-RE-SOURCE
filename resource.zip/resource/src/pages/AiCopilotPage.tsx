import React, { useState } from 'react';
import { querySourceAi } from '../services/aiEngine';
import { AiMessage } from '../types';
import {
  Bot,
  Send,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Activity,
  Cpu,
  Layers,
  HelpCircle
} from 'lucide-react';

interface Props {
  onNavigate: (route: string) => void;
}

const PRESET_QUERIES = [
  'Why did waste increase?',
  'What should I fix first?',
  'Where are we wasting water?',
  'Which resource should be moved?',
  'How much food will become surplus tomorrow?',
  'What saved us the most money this month?',
  'Show me today\'s biggest inefficiency.',
];

export const AiCopilotPage: React.FC<Props> = ({ onNavigate }) => {
  const [messages, setMessages] = useState<AiMessage[]>([
    {
      id: 'copilot-init',
      sender: 'assistant',
      timestamp: 'Online Now',
      text: 'Greetings. I am SOURCE AI, the autonomous intelligence engine of RE:SOURCE. I continuously digest telemetry feeds from 16 campus facilities, 5 resource meters, and circular exchange queues. You can query me on anomalies, leaks, demand predictions, or resource routing.',
    },
  ]);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSend = (textToSend?: string) => {
    const query = textToSend || input;
    if (!query.trim()) return;

    const userMsg: AiMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      text: query,
    };

    setMessages(prev => [...prev, userMsg]);
    if (!textToSend) setInput('');
    setIsProcessing(true);

    setTimeout(() => {
      const response = querySourceAi(query);
      setMessages(prev => [...prev, response]);
      setIsProcessing(false);
    }, 400);
  };

  return (
    <div className="min-h-screen bg-[#080c14] text-slate-100 p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-bold">
              AUTONOMOUS RESOURCE COPILOT
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
            SOURCE AI COCKPIT
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 font-mono mt-0.5">
            Deterministic inference engine � Natural language campus diagnostics � 1-click execution
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-slate-400 bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-800">
          <Cpu className="w-4 h-4 text-emerald-400" />
          <span>Local Engine Active � 0ms API Latency</span>
        </div>
      </div>

      {/* Suggested Inquiries Pills */}
      <div className="bg-slate-900/60 p-4 rounded-2xl border border-slate-800 space-y-2">
        <span className="text-[11px] font-mono uppercase text-slate-400 font-bold flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          Suggested Natural Language Inquiries
        </span>
        <div className="flex flex-wrap gap-2">
          {PRESET_QUERIES.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(q)}
              className="text-xs px-3 py-1.5 bg-slate-950 hover:bg-slate-800 text-slate-300 hover:text-white rounded-xl border border-slate-800 transition font-mono"
            >
              "{q}"
            </button>
          ))}
        </div>
      </div>

      {/* Chat Messages Log */}
      <div className="bg-slate-900/40 border border-slate-800 rounded-3xl p-6 min-h-[460px] max-h-[600px] overflow-y-auto space-y-5">
        {messages.map(msg => (
          <div
            key={msg.id}
            className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div className="text-[10px] font-mono text-slate-500 mb-1 px-1">
              {msg.sender === 'user' ? 'OPERATOR' : 'SOURCE AI'} � {msg.timestamp}
            </div>

            <div
              className={`rounded-2xl p-5 max-w-[85%] leading-relaxed text-sm ${
                msg.sender === 'user'
                  ? 'bg-emerald-600 text-white rounded-tr-none shadow-lg'
                  : 'bg-slate-900 border border-slate-700/80 text-slate-200 rounded-tl-none shadow-2xl'
              }`}
            >
              <p className="font-bold">{msg.text}</p>

              {/* Structured Details */}
              {msg.structuredDetails && (
                <div className="mt-4 pt-4 border-t border-slate-800 space-y-3">
                  {msg.structuredDetails.title && (
                    <div className="text-xs font-mono uppercase tracking-wider text-slate-400 font-bold">
                      {msg.structuredDetails.title}
                    </div>
                  )}

                  {msg.structuredDetails.stats && (
                    <div className="grid grid-cols-1 gap-2 bg-slate-950/80 p-3 rounded-xl border border-slate-800 font-mono text-xs">
                      {msg.structuredDetails.stats.map((st, idx) => (
                        <div key={idx} className="flex items-center justify-between">
                          <span className="text-slate-400">{st.label}</span>
                          <strong className={st.color || 'text-white'}>{st.value}</strong>
                        </div>
                      ))}
                    </div>
                  )}

                  {msg.structuredDetails.causes && (
                    <div className="space-y-1">
                      <span className="text-[11px] font-mono text-slate-400 uppercase">Diagnosed Root Causes:</span>
                      <ul className="list-disc list-inside text-xs text-slate-300 space-y-1">
                        {msg.structuredDetails.causes.map((c, idx) => (
                          <li key={idx}>{c}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {msg.structuredDetails.actions && (
                    <div className="pt-2 flex flex-col gap-2">
                      {msg.structuredDetails.actions.map((act, idx) => (
                        <button
                          key={idx}
                          onClick={() => {
                            if (act.route) onNavigate(act.route);
                          }}
                          className="flex items-center justify-between text-xs px-4 py-2.5 bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 rounded-xl border border-emerald-500/30 transition group font-bold"
                        >
                          <span>{act.label}</span>
                          <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}

        {isProcessing && (
          <div className="flex items-center gap-2 text-xs font-mono text-slate-400 p-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            Synthesizing campus sensory data...
          </div>
        )}
      </div>

      {/* Input Field */}
      <div className="bg-slate-900/90 p-4 rounded-2xl border border-slate-800">
        <form
          onSubmit={e => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center gap-3"
        >
          <input
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            placeholder="Type any campus query: 'Why did waste increase?', 'What should I fix first?'..."
            className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 font-mono"
          />
          <button
            type="submit"
            className="px-6 py-3 bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-bold rounded-xl transition shadow-lg shadow-emerald-500/20 flex items-center gap-2"
          >
            <span>Ask AI</span>
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
