import React, { useState } from 'react';
import { useResource } from '../context/ResourceContext';
import { FacilityNode } from '../types';
import {
  MapPin,
  Layers,
  Activity,
  AlertTriangle,
  ArrowRight,
  Truck,
  Compass,
  X,
  Radio,
  Zap,
  Droplets,
  Utensils
} from 'lucide-react';

interface Props {
  onNavigate: (route: string) => void;
  onInspectAlert: (alertId: string) => void;
}

export const MapPage: React.FC<Props> = ({ onNavigate, onInspectAlert }) => {
  const { facilities, transfers, alerts } = useResource();
  const [selectedFacility, setSelectedFacility] = useState<FacilityNode | null>(facilities[1]); // Default to Block B

  return (
    <div className="min-h-screen bg-[#080c14] text-slate-100 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-bold">
              SPATIAL RESOURCE GIS COMMAND
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
            LIVE RESOURCE MAP
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 font-mono mt-0.5">
            Geographic campus topology � Real-time movement lines � Node telemetry telemetry
          </p>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-3 text-xs font-mono overflow-x-auto p-2 bg-slate-900 rounded-xl border border-slate-800">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" /> Anomaly Hotspot
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" /> Surplus Source
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400" /> Demand Destination
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-slate-400" /> Standard Node
          </div>
        </div>
      </div>

      {/* Map Canvas and Drawer Container */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Interactive SVG Campus Map */}
        <div className="lg:col-span-8 bg-slate-950/90 border border-slate-800 rounded-3xl p-6 relative overflow-hidden shadow-2xl min-h-[540px] flex items-center justify-center">
          {/* Radar background circles */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-20">
            <div className="w-[600px] h-[600px] rounded-full border border-emerald-500/30 animate-pulse-subtle" />
            <div className="w-[400px] h-[400px] rounded-full border border-emerald-500/20 absolute" />
            <div className="w-[200px] h-[200px] rounded-full border border-emerald-500/10 absolute" />
          </div>

          {/* SVG Connection Lines & Active Movement Corridors */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none">
            {/* Transfer Line: Cafeteria A (20%, 70%) to Hostel C (82%, 45%) */}
            <path
              d="M 160 380 Q 400 200 650 250"
              fill="none"
              stroke="#10b981"
              strokeWidth="2"
              strokeDasharray="6 6"
              className="animate-flow"
              opacity="0.8"
            />
            {/* Transfer Line: Cafeteria A to Community Kitchen B (city vector) */}
            <path
              d="M 160 380 Q 250 480 300 520"
              fill="none"
              stroke="#06b6d4"
              strokeWidth="2"
              strokeDasharray="6 6"
              className="animate-flow"
              opacity="0.8"
            />
            {/* Active Anomaly Vector: Block B Pipe Manifold */}
            <circle cx="360" cy="140" r="28" fill="none" stroke="#f43f5e" strokeWidth="1.5" className="animate-ping" opacity="0.6" />
          </svg>

          {/* Render Facility Interactive Nodes */}
          <div className="relative w-full h-full min-h-[480px]">
            {facilities.map(fac => {
              const isSelected = selectedFacility?.id === fac.id;
              const isHotspot = fac.id === 'fac-2'; // Block B
              const isSurplus = fac.id === 'fac-6'; // Cafeteria A
              const isDemand = fac.id === 'fac-9'; // Hostel C

              let nodeBg = 'bg-slate-800 text-slate-300 border-slate-700';
              if (isHotspot) nodeBg = 'bg-rose-500 text-white border-rose-300 shadow-[0_0_20px_rgba(244,63,94,0.7)] animate-pulse';
              else if (isSurplus) nodeBg = 'bg-emerald-500 text-slate-950 border-emerald-300 shadow-[0_0_15px_rgba(16,185,129,0.6)]';
              else if (isDemand) nodeBg = 'bg-cyan-500 text-slate-950 border-cyan-300 shadow-[0_0_15px_rgba(6,182,212,0.6)]';

              return (
                <div
                  key={fac.id}
                  onClick={() => setSelectedFacility(fac)}
                  style={{ left: `${fac.x}%`, top: `${fac.y}%` }}
                  className={`absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-all transform hover:scale-125 z-20 group`}
                >
                  <div
                    className={`w-9 h-9 rounded-xl border flex items-center justify-center font-mono font-bold text-xs ${nodeBg} ${
                      isSelected ? 'ring-4 ring-white' : ''
                    }`}
                  >
                    {fac.code.slice(0, 3)}
                  </div>

                  {/* Tooltip on hover */}
                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover:block bg-slate-900 text-white text-[10px] font-mono whitespace-nowrap px-2 py-1 rounded shadow-lg border border-slate-700 z-30">
                    {fac.name}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="absolute bottom-4 left-4 text-xs font-mono text-slate-400 bg-slate-900/80 px-3 py-1.5 rounded-xl border border-slate-800 backdrop-blur-md">
            Click any node on the campus grid to inspect live sub-meters
          </div>
        </div>

        {/* Selected Facility Details Drawer */}
        <div className="lg:col-span-4 space-y-4">
          {selectedFacility ? (
            <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 space-y-6 shadow-xl">
              <div className="flex items-start justify-between pb-4 border-b border-slate-800">
                <div>
                  <span className="text-[10px] font-mono uppercase bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-bold">
                    {selectedFacility.code} � {selectedFacility.type}
                  </span>
                  <h3 className="text-lg font-bold text-white mt-1">{selectedFacility.name}</h3>
                </div>
                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                    selectedFacility.status === 'critical'
                      ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40 animate-pulse'
                      : 'bg-emerald-500/20 text-emerald-400'
                  }`}
                >
                  {selectedFacility.status}
                </span>
              </div>

              {/* Consumption grid */}
              <div className="space-y-2">
                <span className="text-xs font-mono uppercase text-slate-400 font-bold block">
                  Current Telemetry Feed
                </span>
                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Water Flow</span>
                    <strong className="text-white font-bold">{selectedFacility.currentConsumption.waterL.toLocaleString()} L</strong>
                  </div>
                  <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Energy Draw</span>
                    <strong className="text-white font-bold">{selectedFacility.currentConsumption.energyKwh} kWh</strong>
                  </div>
                  <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Food Staged</span>
                    <strong className="text-white font-bold">{selectedFacility.currentConsumption.foodKg} kg</strong>
                  </div>
                  <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Waste Volume</span>
                    <strong className="text-white font-bold">{selectedFacility.currentConsumption.wasteKg} kg</strong>
                  </div>
                </div>
              </div>

              {/* Sub-meters list */}
              {selectedFacility.meters.length > 0 && (
                <div className="space-y-2">
                  <span className="text-xs font-mono uppercase text-slate-400 font-bold block">
                    Telemetry Sensors In Situ
                  </span>
                  <div className="space-y-1.5">
                    {selectedFacility.meters.map(m => (
                      <div
                        key={m.id}
                        className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between text-xs font-mono"
                      >
                        <div>
                          <span className="text-white font-bold">{m.meterType} Sensor</span>
                          <span className="text-slate-500 text-[10px] block">{m.id}</span>
                        </div>
                        <div className="text-right">
                          <span className={m.status === 'anomaly' ? 'text-rose-400 font-bold' : 'text-emerald-400'}>
                            {m.currentReading} {m.unit}
                          </span>
                          <span className="text-[10px] text-slate-500 block">Base: {m.baseline}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Special facility CTA */}
              {selectedFacility.id === 'fac-2' && (
                <div className="bg-rose-950/20 border border-rose-500/40 p-4 rounded-xl space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-rose-400 font-mono">
                    <AlertTriangle className="w-4 h-4" />
                    <span>Overnight Leak Anomaly Isolated Here</span>
                  </div>
                  <p className="text-xs text-slate-300">
                    Manifold W-04 continuous pressurized loss. Inspect alert ticket to dispatch emergency plumbing crew.
                  </p>
                  <button
                    onClick={() => onInspectAlert('alt-001')}
                    className="w-full py-2 bg-rose-500 hover:bg-rose-400 text-white text-xs font-bold rounded-lg transition"
                  >
                    Inspect Critical Alert Ticket
                  </button>
                </div>
              )}

              {selectedFacility.id === 'fac-6' && (
                <div className="bg-emerald-950/20 border border-emerald-500/40 p-4 rounded-xl space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 font-mono">
                    <Utensils className="w-4 h-4" />
                    <span>55 kg Surplus Meals Ready for Dispatch</span>
                  </div>
                  <button
                    onClick={() => onNavigate('/matches')}
                    className="w-full py-2 bg-emerald-400 hover:bg-emerald-300 text-slate-950 text-xs font-bold rounded-lg transition"
                  >
                    Launch Match Engine Now
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-slate-900/60 p-8 rounded-3xl border border-slate-800 text-center text-slate-400 font-mono">
              Click a campus node to inspect its sensory feed.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
