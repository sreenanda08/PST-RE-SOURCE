import React from 'react';
import { useResource } from '../context/ResourceContext';
import {
  Activity,
  Droplets,
  Zap,
  Utensils,
  Package,
  Trash2,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  TrendingDown,
  CheckCircle2,
  Sparkles,
  ShieldAlert,
  Compass,
  Play,
  RotateCcw,
  Clock,
  Layers,
  ChevronRight
} from 'lucide-react';

interface Props {
  onNavigate: (route: string) => void;
  onOpenAiDrawer: () => void;
  onInspectAlert: (alertId: string) => void;
}

export const DashboardPage: React.FC<Props> = ({ onNavigate, onOpenAiDrawer, onInspectAlert }) => {
  const {
    telemetry,
    impactMetrics,
    alerts,
    executeAllocation,
    startCompetitionDemo,
    triggerTestAnomaly,
  } = useResource();

  const activeCriticalAlerts = alerts.filter(a => a.severity === 'CRITICAL' && a.status !== 'RESOLVED');

  const getStreamIcon = (type: string) => {
    switch (type) {
      case 'WATER':
        return Droplets;
      case 'ENERGY':
        return Zap;
      case 'FOOD':
        return Utensils;
      case 'MATERIALS':
        return Package;
      default:
        return Trash2;
    }
  };

  const getStreamColor = (type: string) => {
    switch (type) {
      case 'WATER':
        return 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30';
      case 'ENERGY':
        return 'text-amber-400 bg-amber-500/10 border-amber-500/30';
      case 'FOOD':
        return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30';
      case 'MATERIALS':
        return 'text-teal-400 bg-teal-500/10 border-teal-500/30';
      default:
        return 'text-rose-400 bg-rose-500/10 border-rose-500/30';
    }
  };

  return (
    <div className="min-h-screen bg-[#080c14] text-slate-100 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-bold">
              SYSTEM LIVE � APEX CAMPUS CONTROLLER
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
            RESOURCE COMMAND CENTER
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 font-mono mt-0.5">
            Observing consumption � Detecting anomalies � Moving surplus
          </p>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={() => onNavigate('/matches')}
            className="px-3.5 py-2 text-xs font-bold bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-300 border border-cyan-500/30 rounded-xl transition flex items-center gap-1.5"
          >
            <Compass className="w-4 h-4 text-cyan-400" />
            <span>Launch Match Engine</span>
          </button>

          <button
            onClick={triggerTestAnomaly}
            className="px-3.5 py-2 text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 rounded-xl transition flex items-center gap-1.5"
          >
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <span>Simulate Anomaly</span>
          </button>

          <button
            onClick={startCompetitionDemo}
            className="px-4 py-2 text-xs font-bold bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 text-slate-950 rounded-xl shadow-lg shadow-emerald-500/20 transition flex items-center gap-1.5"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Run 90s Story</span>
          </button>
        </div>
      </div>

      {/* Top-Level KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* RESOURCE HEALTH */}
        <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800/80 relative overflow-hidden group hover:border-slate-700 transition">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono uppercase tracking-wider text-slate-400 font-bold">
              RESOURCE HEALTH
            </span>
            <Activity className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl sm:text-4xl font-extrabold text-white font-mono">
              {impactMetrics.healthScore}
            </span>
            <span className="text-sm font-mono text-slate-400">/ 100</span>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
            <span className="text-emerald-400 flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5" /> +5 pts this cycle
            </span>
            <span className="font-mono text-[11px]">OPTIMAL BAND</span>
          </div>
          {/* Health bar */}
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-3 overflow-hidden">
            <div
              className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full transition-all duration-500"
              style={{ width: `${impactMetrics.healthScore}%` }}
            />
          </div>
        </div>

        {/* WASTE PREVENTED */}
        <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800/80 relative overflow-hidden group hover:border-slate-700 transition">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono uppercase tracking-wider text-slate-400 font-bold">
              WASTE PREVENTED
            </span>
            <ShieldAlert className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl sm:text-4xl font-extrabold text-white font-mono">
              {impactMetrics.wastePreventedKg.toLocaleString()}
            </span>
            <span className="text-sm font-mono text-slate-400">kg</span>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
            <span className="text-emerald-400 font-mono">+55 kg newly saved</span>
            <span className="font-mono text-[11px]">89% DIVERSION</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-3 overflow-hidden">
            <div className="bg-emerald-400 h-full rounded-full" style={{ width: '89%' }} />
          </div>
        </div>

        {/* RESOURCE VALUE RECOVERED */}
        <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800/80 relative overflow-hidden group hover:border-slate-700 transition">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono uppercase tracking-wider text-slate-400 font-bold">
              VALUE RECOVERED
            </span>
            <Sparkles className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl sm:text-4xl font-extrabold text-cyan-300 font-mono">
              ?{(impactMetrics.costRecoveredInr / 100000).toFixed(2)} L
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
            <span className="text-cyan-400 font-mono">+?8,400 allocated</span>
            <span className="font-mono text-[11px]">ROI 3.4x</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-3 overflow-hidden">
            <div className="bg-cyan-400 h-full rounded-full" style={{ width: '78%' }} />
          </div>
        </div>

        {/* CO2 AVOIDED */}
        <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800/80 relative overflow-hidden group hover:border-slate-700 transition">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono uppercase tracking-wider text-slate-400 font-bold">
              CO2 AVOIDED
            </span>
            <RotateCcw className="w-4 h-4 text-teal-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl sm:text-4xl font-extrabold text-teal-300 font-mono">
              {impactMetrics.co2AvoidedTonnes.toFixed(1)}
            </span>
            <span className="text-sm font-mono text-slate-400">tonnes</span>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
            <span className="text-teal-400 font-mono">Equivalent 180 trees</span>
            <span className="font-mono text-[11px]">GHG REDUCTION</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-3 overflow-hidden">
            <div className="bg-teal-400 h-full rounded-full" style={{ width: '92%' }} />
          </div>
        </div>
      </div>

      {/* Prominent NEXT BEST ACTION Engine (Section 19) */}
      <div className="bg-gradient-to-r from-rose-950/40 via-slate-900 to-amber-950/30 border border-rose-500/30 p-6 rounded-2xl relative shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono uppercase bg-rose-500/20 text-rose-300 px-2 py-0.5 rounded font-bold border border-rose-500/40">
                CRITICAL DIRECTIVE
              </span>
              <span className="text-xs font-mono text-slate-400">
                Prioritized via Impact � Urgency � Confidence � Effort
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-white">
              NEXT BEST ACTION: Inspect Block B Water Distribution Line
            </h2>
            <div className="text-xs text-slate-300 max-w-3xl leading-relaxed">
              <strong className="text-white">Why?</strong> Water consumption is{' '}
              <strong className="text-rose-400 font-mono">+18.4% above baseline</strong> between 01:00 AM and 04:00 AM. Acoustic flow signature matches sub-surface distribution pipe crack on Sub-Line W-04.
            </div>
            <div className="text-xs font-mono text-emerald-400 pt-1">
              ? Expected Impact: Save approximately 2,400 � 3,100 Liters/day � Avoid ?4,800/week leak damage
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => onInspectAlert('alt-001')}
              className="px-5 py-3 rounded-xl bg-rose-500 hover:bg-rose-400 text-white font-bold text-xs tracking-wider shadow-lg shadow-rose-500/25 transition active:scale-95 flex items-center gap-2"
            >
              <span>INSPECT ANOMALY</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => onNavigate('/map')}
              className="px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-semibold text-xs border border-slate-700 transition"
            >
              Locate on Map
            </button>
          </div>
        </div>
      </div>

      {/* 5 Core Resource Streams (Section 8: Water, Energy, Food, Materials, Waste) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white">Campus Resource Streams</h2>
            <p className="text-xs text-slate-400 font-mono">
              Turning raw telemetry into root-cause detection and actionable workflows
            </p>
          </div>
          <button
            onClick={() => onNavigate('/resources')}
            className="text-xs font-mono text-emerald-400 hover:text-emerald-300 flex items-center gap-1"
          >
            Detailed Sub-Metering <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 gap-4">
          {telemetry.map(stream => {
            const Icon = getStreamIcon(stream.type);
            const colorClass = getStreamColor(stream.type);

            return (
              <div
                key={stream.type}
                className="bg-slate-900/70 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition space-y-4"
              >
                {/* Header row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl border flex items-center justify-center ${colorClass}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-extrabold text-white text-base tracking-wide">
                          {stream.type}
                        </h3>
                        <span className="text-xs text-slate-400 font-mono">({stream.name})</span>
                      </div>
                      <div className="flex items-center gap-3 text-xs font-mono mt-0.5">
                        <span className="text-white font-bold text-sm">
                          {stream.currentValue.toLocaleString()} {stream.unit}
                        </span>
                        <span className="text-slate-500">�</span>
                        <span className="text-slate-400">
                          Baseline: {stream.baselineValue.toLocaleString()}
                        </span>
                        <span className="text-slate-500">�</span>
                        <span
                          className={`font-bold ${
                            stream.trendPercentage > 0 ? 'text-rose-400' : 'text-emerald-400'
                          }`}
                        >
                          {stream.trendPercentage > 0 ? `+${stream.trendPercentage}%` : `${stream.trendPercentage}%`} vs baseline
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Status & Efficiency */}
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <div className="text-[10px] font-mono text-slate-400 uppercase">Efficiency Score</div>
                      <div className="text-sm font-mono font-bold text-white">
                        {stream.efficiencyScore}/100
                      </div>
                    </div>
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-mono font-bold border ${
                        stream.status === 'CRITICAL'
                          ? 'bg-rose-500/10 text-rose-400 border-rose-500/30 animate-pulse'
                          : stream.status === 'SURPLUS'
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                          : stream.status === 'ELEVATED'
                          ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                          : 'bg-slate-800 text-slate-300 border-slate-700'
                      }`}
                    >
                      {stream.status}
                    </span>
                  </div>
                </div>

                {/* AI Detection & Action Container */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-3 pt-3 border-t border-slate-800/80 items-center">
                  <div className="md:col-span-8 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                    <div className="flex items-center gap-1.5 text-[11px] font-mono text-cyan-400 uppercase font-bold mb-1">
                      <Sparkles className="w-3.5 h-3.5" />
                      AI DETECTION
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed font-mono">
                      {stream.aiDetection}
                    </p>
                  </div>

                  <div className="md:col-span-4 flex flex-col justify-between h-full space-y-2">
                    <div className="text-[11px] font-mono text-emerald-400 uppercase font-bold">
                      RECOMMENDED ACTION:
                    </div>
                    <button
                      onClick={() => {
                        if (stream.type === 'FOOD') {
                          onNavigate('/matches');
                        } else if (stream.type === 'WATER') {
                          onInspectAlert('alt-001');
                        } else {
                          onNavigate('/resources');
                        }
                      }}
                      className="w-full px-3 py-2 text-xs font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-xl transition shadow-md flex items-center justify-center gap-1.5"
                    >
                      <span>{stream.recommendedAction.split('.')[0]}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Bottom Grid: Active Transfers & Copilot Launcher */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-4">
        {/* Active Circular Transfers */}
        <div className="bg-slate-900/70 p-5 rounded-2xl border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-emerald-400" />
              <h3 className="font-bold text-white text-base">Active Circular Transfers</h3>
            </div>
            <button
              onClick={() => onNavigate('/map')}
              className="text-xs font-mono text-emerald-400 hover:text-emerald-300"
            >
              Track on Map ?
            </button>
          </div>

          <div className="space-y-2.5">
            <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-white">TRF-1092 � 80 kg Organics</span>
                  <span className="text-[10px] font-mono bg-cyan-500/20 text-cyan-400 px-1.5 py-0.2 rounded">
                    IN TRANSIT
                  </span>
                </div>
                <div className="text-xs text-slate-400 font-mono mt-0.5">
                  Cafeteria B ? Bio-Digestion Plant (Courier: EV-2)
                </div>
              </div>
              <div className="text-right font-mono text-xs text-emerald-400 font-bold">
                ETA 14:15 PM
              </div>
            </div>

            <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-white">TRF-1091 � 120 Academic Chairs</span>
                  <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-400 px-1.5 py-0.2 rounded">
                    VERIFIED
                  </span>
                </div>
                <div className="text-xs text-slate-400 font-mono mt-0.5">
                  Block A Admin ? Hostel Block D Lounge
                </div>
              </div>
              <div className="text-right font-mono text-xs text-slate-400">
                Delivered 12:00 PM
              </div>
            </div>
          </div>
        </div>

        {/* Persistent SOURCE AI Teaser Card */}
        <div className="bg-gradient-to-br from-slate-900 to-emerald-950/40 p-5 rounded-2xl border border-emerald-500/30 flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center gap-2 text-emerald-400 text-xs font-mono uppercase tracking-wider font-bold mb-1">
              <Sparkles className="w-4 h-4" /> AI COGNITIVE COPILOT
            </div>
            <h3 className="text-lg font-bold text-white">Have a question about campus resources?</h3>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">
              Ask SOURCE AI about overnight leak diagnostics, lean dining production limits, upcoming furniture surplus, or where to route excess energy.
            </p>
          </div>

          <div className="flex items-center gap-2 pt-2">
            <button
              onClick={onOpenAiDrawer}
              className="flex-1 px-4 py-2.5 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-bold text-xs tracking-wide shadow-md transition"
            >
              Ask SOURCE AI Now
            </button>
            <button
              onClick={() => onNavigate('/ai')}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs border border-slate-700 transition"
            >
              Open AI Cockpit
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
