import React from 'react';
import { useResource } from '../context/ResourceContext';
import {
  Trash2,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  ArrowRight,
  Sparkles,
  ShieldCheck,
  CheckCircle,
  Coins,
  MapPin,
  Calendar
} from 'lucide-react';

interface Props {
  onNavigate: (route: string) => void;
}

export const WastePage: React.FC<Props> = ({ onNavigate }) => {
  const { wasteHotspots, impactMetrics } = useResource();

  return (
    <div className="min-h-screen bg-[#080c14] text-slate-100 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-400 animate-pulse" />
            <span className="text-xs font-mono uppercase tracking-widest text-rose-400 font-bold">
              ROOT CAUSE & INTERCEPTION
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
            WASTE INTELLIGENCE CENTER
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 font-mono mt-0.5">
            Hotspot detection � Category breakdown � Cost of avoidable waste � AI mitigation levers
          </p>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-3 py-1.5 rounded-xl border border-emerald-500/30 font-bold">
            Campus Diversion Rate: 89.2%
          </span>
        </div>
      </div>

      {/* Top Impact Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
          <span className="text-xs font-mono uppercase text-slate-400 font-bold block">
            TOTAL WASTE PREVENTED
          </span>
          <div className="text-3xl font-extrabold font-mono text-emerald-400 mt-2">
            {impactMetrics.wastePreventedKg.toLocaleString()} kg
          </div>
          <p className="text-xs text-slate-400 mt-1 font-mono">Diverted via circular redistribution & composting</p>
        </div>

        <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
          <span className="text-xs font-mono uppercase text-slate-400 font-bold block">
            CURRENT RESIDUAL UNSEGREGATED
          </span>
          <div className="text-3xl font-extrabold font-mono text-white mt-2">
            142 kg
          </div>
          <p className="text-xs text-emerald-400 mt-1 font-mono">-23.2% vs weekly historical baseline</p>
        </div>

        <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
          <span className="text-xs font-mono uppercase text-slate-400 font-bold block">
            AVOIDED DISPOSAL TARIFFS
          </span>
          <div className="text-3xl font-extrabold font-mono text-cyan-300 mt-2">
            ?{(impactMetrics.costRecoveredInr / 100000).toFixed(2)} L
          </div>
          <p className="text-xs text-slate-400 mt-1 font-mono">Net economic value retained on campus</p>
        </div>
      </div>

      {/* Prominent Hotspot Detection Alert (Section 14) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-400" />
            Detected Campus Waste Hotspots
          </h2>
          <span className="text-xs font-mono text-slate-400">Optical sensors & telemetry auditing</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {wasteHotspots.map(spot => (
            <div
              key={spot.id}
              className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition space-y-4 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-mono uppercase bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-bold">
                    {spot.category}
                  </span>
                  <span className="text-xs font-mono text-rose-400 font-bold">
                    {spot.wasteDeviation}
                  </span>
                </div>

                <h3 className="text-base font-bold text-white">{spot.facility}</h3>

                <div className="mt-3 p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                  <div className="text-[11px] text-slate-400 font-mono">
                    <strong className="text-slate-300">Diagnosed Cause:</strong> {spot.likelyCause}
                  </div>
                  <div className="text-[11px] text-emerald-400 font-mono">
                    <strong className="text-emerald-300">AI Fix:</strong> {spot.aiRecommendation}
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono">
                <div>
                  <span className="text-slate-500 text-[10px] block">Preventable Volume</span>
                  <strong className="text-white">{spot.preventableKg} kg</strong>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px] block">Cost Leak</span>
                  <strong className="text-rose-400">?{spot.costImpactInr.toLocaleString()}</strong>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Waste Audit Log Table */}
      <div className="bg-slate-900/70 p-6 rounded-2xl border border-slate-800 space-y-4">
        <h3 className="text-base font-bold text-white">Stream Composition & Segregation Audit</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-xs font-mono text-left">
            <thead className="text-slate-400 uppercase bg-slate-950/80 border-b border-slate-800">
              <tr>
                <th className="p-3">Stream Category</th>
                <th className="p-3">Primary Source</th>
                <th className="p-3">Weekly Volume</th>
                <th className="p-3">Diversion Route</th>
                <th className="p-3">Contamination</th>
                <th className="p-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              <tr>
                <td className="p-3 font-bold text-white">Food / Wet Organics</td>
                <td className="p-3">Dining Halls A & B</td>
                <td className="p-3">1,420 kg</td>
                <td className="p-3 text-emerald-400">East Biodigester & Composting</td>
                <td className="p-3">2.4% (Low)</td>
                <td className="p-3"><span className="text-emerald-400 font-bold">OPTIMAL</span></td>
              </tr>
              <tr>
                <td className="p-3 font-bold text-white">Packaging / Corrugated</td>
                <td className="p-3">Logistics Depot Gate 4</td>
                <td className="p-3">680 kg</td>
                <td className="p-3 text-cyan-400">MakerSpace Upcycling & Pulp Mill</td>
                <td className="p-3">4.1%</td>
                <td className="p-3"><span className="text-emerald-400 font-bold">OPTIMAL</span></td>
              </tr>
              <tr>
                <td className="p-3 font-bold text-white">Laboratory Glass & Plastics</td>
                <td className="p-3">Labs 1 & 2</td>
                <td className="p-3">210 kg</td>
                <td className="p-3 text-amber-400">Autoclave Sterilization & Regrind</td>
                <td className="p-3">1.2%</td>
                <td className="p-3"><span className="text-amber-400 font-bold">STAGING</span></td>
              </tr>
              <tr>
                <td className="p-3 font-bold text-white">Electronic Waste</td>
                <td className="p-3">Computing Center Block A</td>
                <td className="p-3">45 kg</td>
                <td className="p-3 text-indigo-400">Hardware Component Harvesting</td>
                <td className="p-3">0.0%</td>
                <td className="p-3"><span className="text-cyan-400 font-bold">RECOVERED</span></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
