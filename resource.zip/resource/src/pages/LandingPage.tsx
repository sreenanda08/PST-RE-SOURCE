import React, { useState } from 'react';
import {
  ArrowRight,
  Activity,
  Zap,
  Droplets,
  Utensils,
  Package,
  Trash2,
  TrendingUp,
  Cpu,
  Globe,
  CheckCircle2,
  AlertTriangle,
  Play,
  RotateCcw
} from 'lucide-react';

interface Props {
  onNavigate: (route: string) => void;
  onStartDemo: () => void;
}

export const LandingPage: React.FC<Props> = ({ onNavigate, onStartDemo }) => {
  const [activeStream, setActiveStream] = useState<'WATER' | 'ENERGY' | 'FOOD' | 'MATERIALS' | 'WASTE'>('FOOD');

  const streamDetails = {
    FOOD: {
      color: 'from-amber-400 to-orange-500',
      textColor: 'text-amber-400',
      source: 'Central Cafeteria A (55 kg surplus detected)',
      storage: 'Insulated Holding Bay 2 (Safe window 3.5h)',
      demand: 'Hostel Block C (15 kg) + Community Kitchen B (40 kg)',
      action: 'Automated Dual-Allocation & Courier EV-1 Dispatched',
    },
    WATER: {
      color: 'from-cyan-400 to-blue-500',
      textColor: 'text-cyan-400',
      source: 'Block B Distribution Line (+18.4% overnight anomaly)',
      storage: 'Central Pressure Manifold W-04',
      demand: 'Acoustic Leak Detection Sensor Matrix',
      action: 'Emergency Isolation Ticket Auto-Drafted & Assigned',
    },
    ENERGY: {
      color: 'from-yellow-400 to-amber-500',
      textColor: 'text-yellow-400',
      source: 'Block A Chiller 3 (Active cooling past 18:00)',
      storage: 'Sub-station Transformer Bank 2',
      demand: 'Peak Grid Tariff Minimization Engine',
      action: 'BMS Zone 4 Setpoint Reset to 24.5�C Eco Mode',
    },
    MATERIALS: {
      color: 'from-emerald-400 to-teal-500',
      textColor: 'text-emerald-400',
      source: 'Central Warehouse (180 heavy-duty shipping cartons)',
      storage: 'Gate 4 Staging Yard',
      demand: 'MakerSpace Fabrication Workshop',
      action: 'Upcycling Circular Transfer Order M-882 Verified',
    },
    WASTE: {
      color: 'from-rose-400 to-pink-500',
      textColor: 'text-rose-400',
      source: 'Dining Halls Organic Pre-Sorted Greens (142 kg)',
      storage: 'Pneumatic Compaction Vault B',
      demand: 'East Campus Bio-Digestion Methane Reactor',
      action: 'Converted into 62 kWh Renewable Electricity',
    },
  };

  const curr = streamDetails[activeStream];

  return (
    <div className="min-h-screen bg-[#080c14] text-slate-100 bg-grid-pattern">
      {/* Top Banner Ticker */}
      <div className="bg-slate-950/80 border-b border-slate-800/80 px-4 py-2 text-xs font-mono text-slate-400 flex items-center justify-between overflow-x-auto whitespace-nowrap">
        <div className="flex items-center gap-6">
          <span className="flex items-center gap-1.5 text-emerald-400 font-semibold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            LIVE CAMPUS TELEMETRY
          </span>
          <span>HEALTH SCORE: <strong className="text-white font-bold">87/100</strong></span>
          <span>WASTE PREVENTED: <strong className="text-emerald-300">12,482 kg</strong></span>
          <span>VALUE RECOVERED: <strong className="text-cyan-300">?2.84 L</strong></span>
          <span>CO2 AVOIDED: <strong className="text-teal-300">4.7 t</strong></span>
          <span className="text-rose-400">ALERT: Block B Water Anomaly Active (+18.4%)</span>
        </div>
        <div className="hidden md:flex items-center gap-2 text-slate-400">
          <span>Apex University Campus Testbed</span>
        </div>
      </div>

      {/* Hero Section */}
      <section className="relative pt-16 pb-24 px-4 max-w-7xl mx-auto text-center">
        {/* Glow ambient circle */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-gradient-to-tr from-emerald-600/15 via-cyan-500/10 to-transparent blur-[120px] pointer-events-none" />

        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-mono uppercase tracking-wider mb-6">
          <Cpu className="w-3.5 h-3.5" />
          Autonomous Resource Intelligence & Allocation Control Center
        </div>

        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white max-w-5xl mx-auto leading-[1.1] mb-6">
          See the waste.{' '}
          <span className="bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 bg-clip-text text-transparent">
            Predict the need.
          </span>{' '}
          Move the resource.
        </h1>

        <p className="text-base sm:text-lg text-slate-300 max-w-3xl mx-auto leading-relaxed mb-10 font-normal">
          An AI-powered resource intelligence network that predicts waste, detects inefficiencies, and reallocates surplus across institutions before valuable resources become waste.
        </p>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
          <button
            onClick={() => onNavigate('/dashboard')}
            className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 text-slate-950 font-bold text-sm tracking-wide shadow-xl shadow-emerald-500/25 flex items-center justify-center gap-2 transition transform active:scale-95"
          >
            <span>ENTER CONTROL CENTER</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={onStartDemo}
            className="w-full sm:w-auto px-7 py-4 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 hover:text-white font-semibold text-sm border border-slate-700/80 flex items-center justify-center gap-2 transition"
          >
            <Play className="w-4 h-4 text-amber-400 fill-amber-400" />
            <span>RUN 90-SECOND COMPETITION STORY</span>
          </button>
        </div>

        {/* Interactive Animated Hero Visualizer */}
        <div className="max-w-5xl mx-auto bg-slate-900/80 border border-slate-700/80 rounded-2xl p-6 sm:p-8 backdrop-blur-xl shadow-2xl relative text-left">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-slate-800 gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                <h3 className="font-bold text-white text-base">Active Resource Flow Matrix</h3>
              </div>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                Simulated real-time circular movement between Source, Storage, Demand, and Action
              </p>
            </div>

            {/* Stream Selector Buttons */}
            <div className="flex items-center gap-1.5 overflow-x-auto p-1 bg-slate-950 rounded-xl border border-slate-800">
              {(['FOOD', 'WATER', 'ENERGY', 'MATERIALS', 'WASTE'] as const).map(stream => (
                <button
                  key={stream}
                  onClick={() => setActiveStream(stream)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition ${
                    activeStream === stream
                      ? 'bg-slate-800 text-white shadow-sm border border-slate-700'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {stream}
                </button>
              ))}
            </div>
          </div>

          {/* Interactive Flow Visualizer Pipeline */}
          <div className="py-8 grid grid-cols-1 md:grid-cols-4 gap-4 relative">
            {/* Stage 1: SOURCE */}
            <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 relative hover:border-slate-700 transition">
              <span className="text-[10px] font-mono uppercase bg-slate-800 text-slate-400 px-2 py-0.5 rounded font-bold">
                01 SOURCE
              </span>
              <h4 className="text-sm font-bold text-white mt-2 mb-1">Origin Node</h4>
              <p className="text-xs text-slate-300 leading-relaxed font-mono">{curr.source}</p>
            </div>

            {/* Stage 2: STORAGE */}
            <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 relative hover:border-slate-700 transition">
              <span className="text-[10px] font-mono uppercase bg-slate-800 text-slate-400 px-2 py-0.5 rounded font-bold">
                02 STORAGE
              </span>
              <h4 className="text-sm font-bold text-white mt-2 mb-1">State & Expiry</h4>
              <p className="text-xs text-slate-300 leading-relaxed font-mono">{curr.storage}</p>
            </div>

            {/* Stage 3: DEMAND */}
            <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 relative hover:border-slate-700 transition">
              <span className="text-[10px] font-mono uppercase bg-slate-800 text-slate-400 px-2 py-0.5 rounded font-bold">
                03 DEMAND
              </span>
              <h4 className="text-sm font-bold text-white mt-2 mb-1">AI Matched Needs</h4>
              <p className="text-xs text-slate-300 leading-relaxed font-mono">{curr.demand}</p>
            </div>

            {/* Stage 4: ACTION */}
            <div className="bg-emerald-950/30 p-4 rounded-xl border border-emerald-500/40 relative">
              <span className="text-[10px] font-mono uppercase bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded font-bold border border-emerald-500/30">
                04 ACTION
              </span>
              <h4 className="text-sm font-bold text-emerald-300 mt-2 mb-1">Next Best Move</h4>
              <p className="text-xs text-emerald-200/90 leading-relaxed font-mono">{curr.action}</p>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 font-mono gap-2">
            <span>Algorithm: Bayesian Markov Demand Prediction + Distance Weighting</span>
            <button
              onClick={() => onNavigate('/matches')}
              className="text-emerald-400 hover:text-emerald-300 flex items-center gap-1 font-bold"
            >
              Inspect Active Matching Corridor <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </section>

      {/* Section: The Core Problem */}
      <section className="py-20 bg-slate-950/60 border-t border-b border-slate-900">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-xs font-mono uppercase tracking-wider text-rose-400 font-bold">
              THE STRUCTURAL PROBLEM
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2 mb-4">
              Resources Become Waste Because Systems Are Fragmented
            </h2>
            <p className="text-sm text-slate-400 leading-relaxed">
              Most sustainability solutions are historical dashboards. They tell you what you threw away yesterday. RE:SOURCE connects the entire lifecycle before value is lost forever.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-slate-900/60 p-6 rounded-2xl border border-slate-800 hover:border-slate-700 transition">
              <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 mb-4 font-bold">
                01
              </div>
              <h3 className="text-base font-bold text-white mb-2">Isolated Silos</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Cafeteria managers don't know hostel pantries have empty shelves. Water maintenance teams don't see nocturnal acoustic anomalies until bills arrive a month later.
              </p>
            </div>

            <div className="bg-slate-900/60 p-6 rounded-2xl border border-slate-800 hover:border-slate-700 transition">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold">
                02
              </div>
              <h3 className="text-base font-bold text-white mb-2">Zero Predictive Horizon</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Kitchens prepare food based on fixed calendar menus rather than dynamic campus event and exam attendance forecasting, causing chronic 15-20% batch surplus.
              </p>
            </div>

            <div className="bg-slate-900/60 p-6 rounded-2xl border border-slate-800 hover:border-slate-700 transition">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold">
                03
              </div>
              <h3 className="text-base font-bold text-white mb-2">Missing Allocation Layer</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Even when surplus is acknowledged, organizations lack automated route matching, custody logging, and transport dispatch to move materials while still fresh.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Section: The Product Vision */}
      <section className="py-20 px-4 max-w-7xl mx-auto">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-mono uppercase tracking-wider text-emerald-400 font-bold">
            PRODUCT ARCHITECTURE
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2 mb-4">
            An Intelligent Operating System for Physical Resources
          </h2>
          <p className="text-sm text-slate-400 leading-relaxed">
            RE:SOURCE moves organizations from passive monitoring into proactive automated reallocation across 6 key pillars.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            {
              title: 'Bloomberg Terminal for Physical Resources',
              desc: 'High-density, real-time telemetry streaming for water, electricity, food, and physical assets across every campus block.',
              icon: Activity,
              route: '/resources',
            },
            {
              title: 'Google Maps for Resource Movement',
              desc: 'Interactive live campus GIS tracking real-time transit corridors, dynamic particle routes, and active EV courier deliveries.',
              icon: Globe,
              route: '/map',
            },
            {
              title: 'Predictive Horizon Engine',
              desc: 'Bayesian moving averages, scenario simulation sliders, and confidence intervals that predict tomorrow\'s surplus today.',
              icon: TrendingUp,
              route: '/forecast',
            },
            {
              title: 'Algorithmic Resource Matcher',
              desc: 'Multi-criteria score engine weighing quantity compatibility, transit time, expiration urgency, and carbon mitigation.',
              icon: RotateCcw,
              route: '/matches',
            },
            {
              title: 'Circular Resource Exchange',
              desc: 'An internal physical asset marketplace across 11 material categories with digital passports, custody chains, and QR tracking.',
              icon: Package,
              route: '/exchange',
            },
            {
              title: 'SOURCE AI Resource Copilot',
              desc: 'A persistent, context-aware intelligence agent diagnosing root causes, estimating cost impacts, and proposing 1-click fixes.',
              icon: Cpu,
              route: '/ai',
            },
          ].map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                onClick={() => onNavigate(item.route)}
                className="bg-slate-900/50 hover:bg-slate-900 p-6 rounded-2xl border border-slate-800 hover:border-emerald-500/40 transition cursor-pointer group"
              >
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Icon className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-white mb-2 flex items-center justify-between">
                  <span>{item.title}</span>
                  <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-emerald-400 group-hover:translate-x-1 transition-all" />
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">{item.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Target Industries */}
      <section className="py-16 bg-slate-950/80 border-t border-slate-900 text-center">
        <div className="max-w-7xl mx-auto px-4">
          <p className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-6 font-semibold">
            Engineered for Large-Scale Campus & Institutional Ecosystems
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3 text-xs font-mono text-slate-300">
            {[
              'Universities & Campuses',
              'Hospital Networks',
              'Hotel Chains',
              'Municipal Districts',
              'Industrial Manufacturing Hubs',
              'Logistics Warehouses',
              'Large Corporate Campuses',
            ].map((sec, i) => (
              <span key={i} className="px-4 py-2 bg-slate-900 rounded-xl border border-slate-800">
                {sec}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Call to action footer banner */}
      <section className="py-20 px-4 text-center">
        <div className="max-w-4xl mx-auto bg-gradient-to-r from-emerald-950/60 via-slate-900 to-cyan-950/60 p-10 rounded-3xl border border-emerald-500/30 shadow-2xl relative overflow-hidden">
          <h2 className="text-3xl font-extrabold text-white mb-4">
            Step Inside the Resource Operating System
          </h2>
          <p className="text-sm text-slate-300 max-w-xl mx-auto mb-8 leading-relaxed">
            Experience the real-time simulation: diagnose overnight water leaks, forecast cafeteria demand, and match 55 kg of fresh surplus food in seconds.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => onNavigate('/dashboard')}
              className="px-8 py-3.5 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-bold text-sm tracking-wide shadow-lg shadow-emerald-500/25 transition"
            >
              LAUNCH COMMAND CENTER
            </button>
            <button
              onClick={onStartDemo}
              className="px-8 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-sm border border-slate-700 transition"
            >
              START COMPETITION DEMO
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
