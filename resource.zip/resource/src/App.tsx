import React, { useState, useEffect } from 'react';
import { ResourceProvider, useResource } from './context/ResourceContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { CompetitionBanner } from './components/CompetitionBanner';
import { SourceAiDrawer } from './components/SourceAiDrawer';
import { ResourcePassportModal } from './components/ResourcePassportModal';
import { ListResourceModal } from './components/ListResourceModal';
import { ResolveAlertModal } from './components/ResolveAlertModal';

// Pages
import { LandingPage } from './pages/LandingPage';
import { DashboardPage } from './pages/DashboardPage';
import { ResourcesPage } from './pages/ResourcesPage';
import { ForecastPage } from './pages/ForecastPage';
import { MatchesPage } from './pages/MatchesPage';
import { ExchangePage } from './pages/ExchangePage';
import { MapPage } from './pages/MapPage';
import { WastePage } from './pages/WastePage';
import { AlertsPage } from './pages/AlertsPage';
import { ImpactPage } from './pages/ImpactPage';
import { ReportsPage } from './pages/ReportsPage';
import { AiCopilotPage } from './pages/AiCopilotPage';
import { SettingsPage } from './pages/SettingsPage';

const AppContent: React.FC = () => {
  const [currentRoute, setCurrentRoute] = useState<string>('/dashboard');
  const [isAiDrawerOpen, setIsAiDrawerOpen] = useState<boolean>(false);
  const [isListModalOpen, setIsListModalOpen] = useState<boolean>(false);
  const [resolvingAlertId, setResolvingAlertId] = useState<string | null>(null);

  const { setActivePassportId, startCompetitionDemo } = useResource();

  // Listen to browser URL popstate or initial hash
  useEffect(() => {
    const handlePopState = () => {
      const path = window.location.pathname;
      if (path && path !== '/') {
        setCurrentRoute(path);
      }
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (route: string) => {
    setCurrentRoute(route);
    window.history.pushState({}, '', route);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleInspectAlert = (alertId: string) => {
    navigate('/alerts');
  };

  return (
    <div className="min-h-screen bg-[#080c14] text-slate-100 flex flex-col font-sans selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Navbar */}
      <Navbar
        currentRoute={currentRoute}
        onNavigate={navigate}
        onOpenAiDrawer={() => setIsAiDrawerOpen(true)}
      />

      {/* Competition Mode Banner */}
      <CompetitionBanner />

      {/* Page Routing */}
      <main className="flex-1">
        {currentRoute === '/' && (
          <LandingPage onNavigate={navigate} onStartDemo={startCompetitionDemo} />
        )}
        {currentRoute === '/dashboard' && (
          <DashboardPage
            onNavigate={navigate}
            onOpenAiDrawer={() => setIsAiDrawerOpen(true)}
            onInspectAlert={handleInspectAlert}
          />
        )}
        {currentRoute === '/resources' && (
          <ResourcesPage onNavigate={navigate} onInspectAlert={handleInspectAlert} />
        )}
        {currentRoute === '/forecast' && <ForecastPage onNavigate={navigate} />}
        {currentRoute === '/matches' && (
          <MatchesPage
            onNavigate={navigate}
            onOpenPassport={(id) => setActivePassportId(id)}
          />
        )}
        {currentRoute === '/exchange' && (
          <ExchangePage
            onOpenListModal={() => setIsListModalOpen(true)}
            onOpenPassport={(id) => setActivePassportId(id)}
            onNavigate={navigate}
          />
        )}
        {currentRoute === '/map' && (
          <MapPage onNavigate={navigate} onInspectAlert={handleInspectAlert} />
        )}
        {currentRoute === '/waste' && <WastePage onNavigate={navigate} />}
        {currentRoute === '/alerts' && (
          <AlertsPage
            onResolveAlert={(id) => setResolvingAlertId(id)}
            onNavigate={navigate}
          />
        )}
        {currentRoute === '/impact' && <ImpactPage />}
        {currentRoute === '/reports' && <ReportsPage />}
        {currentRoute === '/ai' && <AiCopilotPage onNavigate={navigate} />}
        {currentRoute === '/settings' && <SettingsPage />}
      </main>

      {/* Footer */}
      <Footer onNavigate={navigate} />

      {/* Persistent Source AI Drawer */}
      <SourceAiDrawer
        isOpen={isAiDrawerOpen}
        onClose={() => setIsAiDrawerOpen(false)}
        onNavigate={navigate}
      />

      {/* Digital Resource Passport Modal */}
      <ResourcePassportModal />

      {/* List Resource Modal */}
      <ListResourceModal
        isOpen={isListModalOpen}
        onClose={() => setIsListModalOpen(false)}
      />

      {/* Resolve Alert Modal */}
      <ResolveAlertModal
        alertId={resolvingAlertId}
        onClose={() => setResolvingAlertId(null)}
      />
    </div>
  );
};

export const App: React.FC = () => {
  return (
    <ResourceProvider>
      <AppContent />
    </ResourceProvider>
  );
};

export default App;
