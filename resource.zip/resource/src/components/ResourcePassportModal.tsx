import React from 'react';
import { useResource } from '../context/ResourceContext';
import {
  X,
  QrCode,
  ShieldCheck,
  Clock,
  MapPin,
  TrendingUp,
  Leaf,
  Coins,
  FileCheck,
  CheckCircle,
  Truck
} from 'lucide-react';

export const ResourcePassportModal: React.FC = () => {
  const { activePassportId, setActivePassportId, passports } = useResource();

  if (!activePassportId || !passports[activePassportId]) return null;

  const passport = passports[activePassportId];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-2xl bg-[#0e1628] border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header Bar */}
        <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-cyan-950 p-6 border-b border-slate-700/70 flex items-start justify-between">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-slate-950 border border-emerald-500/40 p-2 flex items-center justify-center shadow-lg">
              {/* Simulated crisp QR code visual */}
              <div className="w-full h-full bg-emerald-400/20 border border-emerald-400 grid grid-cols-3 gap-0.5 p-1 rounded">
                <div className="bg-emerald-400 rounded-sm"></div>
                <div className="bg-transparent"></div>
                <div className="bg-emerald-400 rounded-sm"></div>
                <div className="bg-transparent"></div>
                <div className="bg-emerald-400 rounded-sm"></div>
                <div className="bg-transparent"></div>
                <div className="bg-emerald-400 rounded-sm"></div>
                <div className="bg-transparent"></div>
                <div className="bg-emerald-400 rounded-sm"></div>
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-mono uppercase bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/40 font-bold">
                  DIGITAL RESOURCE PASSPORT
                </span>
                <span className="text-xs font-mono text-slate-400">ID: {passport.id}</span>
              </div>
              <h2 className="text-xl font-bold text-white mt-1">{passport.resourceName}</h2>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                Category: {passport.category} � {passport.quantity} {passport.unit}
              </p>
            </div>
          </div>

          <button
            onClick={() => setActivePassportId(null)}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 max-h-[75vh] overflow-y-auto space-y-6">
          {/* Key metrics grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
              <div className="text-[10px] font-mono uppercase text-slate-400 flex items-center gap-1">
                <Clock className="w-3 h-3 text-cyan-400" /> Minted
              </div>
              <div className="text-xs font-semibold text-white mt-1">{passport.createdTimestamp}</div>
            </div>

            <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
              <div className="text-[10px] font-mono uppercase text-slate-400 flex items-center gap-1">
                <Clock className="w-3 h-3 text-rose-400" /> Safe Window
              </div>
              <div className="text-xs font-semibold text-white mt-1">{passport.expiryTimestamp}</div>
            </div>

            <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
              <div className="text-[10px] font-mono uppercase text-slate-400 flex items-center gap-1">
                <Coins className="w-3 h-3 text-emerald-400" /> Economic Value
              </div>
              <div className="text-sm font-mono font-bold text-emerald-400 mt-0.5">
                ?{passport.economicValueInr.toLocaleString()}
              </div>
            </div>

            <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
              <div className="text-[10px] font-mono uppercase text-slate-400 flex items-center gap-1">
                <Leaf className="w-3 h-3 text-teal-400" /> CO2 Avoided
              </div>
              <div className="text-sm font-mono font-bold text-teal-300 mt-0.5">
                {passport.carbonFootprintAvoidedKg} kg
              </div>
            </div>
          </div>

          {/* Verification Stamps */}
          <div className="bg-emerald-950/20 border border-emerald-500/30 p-4 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <ShieldCheck className="w-7 h-7 text-emerald-400 shrink-0" />
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-300 font-mono">
                  {passport.safetyCertification}
                </h4>
                <p className="text-xs text-slate-300 mt-0.5">
                  Custodian: <span className="font-semibold text-white">{passport.currentCustodian}</span>
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Handling: {passport.storageRequirements}
                </p>
              </div>
            </div>
            <div className="hidden sm:block text-right">
              <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/30 font-bold">
                ? VERIFIED STATUS
              </span>
            </div>
          </div>

          {/* Chain of Custody Timeline */}
          <div>
            <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 font-bold mb-3 flex items-center gap-1.5">
              <FileCheck className="w-4 h-4 text-cyan-400" /> Immutable Chain of Custody Log
            </h4>
            <div className="relative pl-6 space-y-4 border-l border-slate-800 ml-2">
              {passport.custodyHistory.map((item, idx) => (
                <div key={idx} className="relative">
                  {/* Dot */}
                  <div className="absolute -left-[31px] top-1 w-3 h-3 rounded-full bg-emerald-400 border-2 border-slate-900 shadow-[0_0_8px_rgba(16,185,129,0.8)]" />
                  <div className="flex items-baseline justify-between">
                    <span className="text-xs font-bold text-white">{item.event}</span>
                    <span className="text-[10px] font-mono text-slate-400">{item.timestamp}</span>
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">
                    Actor: <span className="text-slate-300">{item.actor}</span> � Location: <span className="text-slate-300">{item.location}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-900/90 border-t border-slate-800 flex items-center justify-between">
          <div className="text-[11px] font-mono text-slate-400">
            Cryptographic SHA-256 Digest: 8f9a2...e41c
          </div>
          <button
            onClick={() => setActivePassportId(null)}
            className="px-4 py-2 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition"
          >
            Close Passport
          </button>
        </div>
      </div>
    </div>
  );
};
