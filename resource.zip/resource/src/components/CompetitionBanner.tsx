import React from 'react';
import { useResource, DEMO_STORY_STEPS } from '../context/ResourceContext';
import { Play, ChevronRight, ChevronLeft, X, Sparkles, CheckCircle2 } from 'lucide-react';

export const CompetitionBanner: React.FC = () => {
  const { isDemoRunning, demoStep, nextDemoStep, prevDemoStep, stopCompetitionDemo } = useResource();

  if (!isDemoRunning) return null;

  const currentInfo = DEMO_STORY_STEPS[demoStep - 1];

  return (
    <div className="sticky top-16 z-40 bg-gradient-to-r from-emerald-950/90 via-slate-900/95 to-cyan-950/90 border-b border-emerald-500/30 backdrop-blur-md shadow-2xl transition-all">
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Step indicator & Info */}
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-emerald-500/20 border border-emerald-400 text-emerald-300 font-mono text-sm font-bold shadow-[0_0_12px_rgba(16,185,129,0.4)]">
            {demoStep}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase font-mono tracking-wider font-semibold text-emerald-400">
                {currentInfo.badge}
              </span>
              <span className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
                Step {demoStep} of 8
              </span>
            </div>
            <h4 className="text-sm md:text-base font-bold text-white flex items-center gap-1.5">
              {currentInfo.title}
            </h4>
          </div>
        </div>

        {/* Story narrative */}
        <div className="text-xs text-slate-300 max-w-xl hidden lg:block leading-relaxed border-l border-slate-700/50 pl-4">
          {currentInfo.narrative}
        </div>

        {/* Step progress pills & Controls */}
        <div className="flex items-center gap-2">
          {/* Progress dots */}
          <div className="flex items-center gap-1 mr-2">
            {DEMO_STORY_STEPS.map((s, idx) => (
              <div
                key={s.step}
                className={`h-1.5 rounded-full transition-all ${
                  idx + 1 === demoStep
                    ? 'w-6 bg-emerald-400'
                    : idx + 1 < demoStep
                    ? 'w-2 bg-emerald-700'
                    : 'w-2 bg-slate-700'
                }`}
              />
            ))}
          </div>

          {demoStep > 1 && (
            <button
              onClick={prevDemoStep}
              className="px-2.5 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700 rounded border border-slate-700 transition"
              title="Previous Step"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          )}

          <button
            onClick={nextDemoStep}
            className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold text-slate-950 bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 rounded shadow-md transition transform active:scale-95"
          >
            <span>{currentInfo.actionLabel || 'Next Step'}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={stopCompetitionDemo}
            className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded transition ml-1"
            title="Exit Competition Mode"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
