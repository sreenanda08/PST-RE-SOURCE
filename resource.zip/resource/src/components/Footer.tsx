import React from 'react';
import { Shield, Cpu, RefreshCw, Globe, ArrowUpRight } from 'lucide-react';

export const Footer: React.FC<{ onNavigate: (route: string) => void }> = ({ onNavigate }) => {
  return (
    <footer className="border-t border-slate-800/80 bg-[#060a12] text-slate-400 py-12 mt-20">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Brand Info */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-emerald-500 flex items-center justify-center font-mono font-bold text-slate-950 text-xs">
                RE
              </div>
              <span className="font-extrabold text-white text-lg tracking-wider">RE:SOURCE</span>
            </div>
            <p className="text-sm font-semibold text-emerald-400 font-mono">
              "See the waste. Predict the need. Move the resource."
            </p>
            <p className="text-xs text-slate-400 max-w-md leading-relaxed">
              An enterprise resource intelligence and circular allocation control center. Connecting energy, water, food, and materials across live supply, predictive demand, and real-time movement corridors.
            </p>
            <div className="flex items-center gap-3 pt-2 text-[11px] font-mono text-slate-400">
              <span className="flex items-center gap-1.5 text-emerald-400">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                Network Synchronized
              </span>
              <span>�</span>
              <span>16 Nodes Live</span>
              <span>�</span>
              <span>Latency 42ms</span>
            </div>
          </div>

          {/* Quick Hub Navigation */}
          <div>
            <h4 className="text-xs font-mono uppercase tracking-wider text-slate-300 font-bold mb-3">
              Intelligence Operations
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onNavigate('/dashboard')} className="hover:text-emerald-400 transition">
                  Command Center
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/resources')} className="hover:text-emerald-400 transition">
                  Resource Telemetry
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/forecast')} className="hover:text-emerald-400 transition">
                  Prediction Center
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/matches')} className="hover:text-emerald-400 transition">
                  Resource Matching Engine
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/exchange')} className="hover:text-emerald-400 transition">
                  Circular Exchange Marketplace
                </button>
              </li>
            </ul>
          </div>

          {/* Analytics & Compliance */}
          <div>
            <h4 className="text-xs font-mono uppercase tracking-wider text-slate-300 font-bold mb-3">
              Compliance & Action
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onNavigate('/map')} className="hover:text-emerald-400 transition">
                  Live Resource Map
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/waste')} className="hover:text-emerald-400 transition">
                  Waste Hotspot Intelligence
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/alerts')} className="hover:text-emerald-400 transition">
                  Anomaly Alert Center
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/impact')} className="hover:text-emerald-400 transition">
                  Impact & ESG Analytics
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/reports')} className="hover:text-emerald-400 transition">
                  Executive Reports
                </button>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-slate-400">
          <div>� 2026 RE:SOURCE Operating System. All rights reserved.</div>
          <div className="flex items-center gap-6">
            <span>Enterprise Edition 2.4</span>
            <span>Zero External API Dependency</span>
            <span className="text-emerald-400">Deterministic AI Layer</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
