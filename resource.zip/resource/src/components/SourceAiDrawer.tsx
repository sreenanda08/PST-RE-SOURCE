import React, { useState } from 'react';
import { querySourceAi } from '../services/aiEngine';
import { AiMessage } from '../types';
import { Bot, Send, X, Sparkles, ArrowRight, Activity, AlertTriangle, ShieldCheck } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (route: string) => void;
}

const PRESET_QUERIES = [
  'Why did waste increase?',
  'What should I fix first?',
  'Where are we wasting water?',
  'Which resource should be moved?',
  'How much food will become surplus tomorrow?',
  'What saved us the most money this month?',
];

export const SourceAiDrawer: React.FC<Props> = ({ isOpen, onClose, onNavigate }) => {
  const [messages, setMessages] = useState<AiMessage[]>([
    {
      id: 'ai-init',
      sender: 'assistant',
      timestamp: 'Active Now',
      text: 'I am SOURCE AI, your autonomous campus resource intelligence copilot. I am actively synthesizing telemetry from 16 facility nodes, 5 meters, and circular exchange queues. How can I optimize campus resources right now?',
    },
  ]);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  const handleSend = (textToSend?: string) => {
    const query = textToSend || input;
    if (!query.trim()) return;

    const userMsg: AiMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      text: query,
    };

    setMessages(prev => [...prev, userMsg]);
    if (!textToSend) setInput('');
    setIsProcessing(true);

    setTimeout(() => {
      const response = querySourceAi(query);
      setMessages(prev => [...prev, response]);
      setIsProcessing(false);
    }, 450);
  };

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full max-w-lg bg-[#0c1220]/95 backdrop-blur-xl border-l border-slate-800 shadow-2xl flex flex-col transition-all duration-300">
      {/* Header */}
      <div className="p-4 border-b border-slate-800/80 flex items-center justify-between bg-slate-900/60">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 to-cyan-500 flex items-center justify-center text-slate-950 font-bold shadow-lg shadow-emerald-500/20">
            <Bot className="w-5 h-5 text-slate-950" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-white text-base tracking-wide">SOURCE AI</h3>
              <span className="flex items-center gap-1 text-[10px] font-mono uppercase bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/30">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                Live Copilot
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono">Resource Intelligence Engine v2.4</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Preset Query Pills */}
      <div className="p-3 border-b border-slate-800/60 bg-slate-950/40">
        <div className="text-[11px] uppercase tracking-wider font-mono text-slate-400 mb-2 flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-cyan-400" /> Suggested Inquiries
        </div>
        <div className="flex flex-wrap gap-1.5">
          {PRESET_QUERIES.map((q, i) => (
            <button
              key={i}
              onClick={() => handleSend(q)}
              className="text-xs px-2.5 py-1 bg-slate-800/70 hover:bg-slate-700 text-slate-300 hover:text-white rounded-full border border-slate-700/60 transition text-left"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Messages Feed */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map(msg => (
          <div
            key={msg.id}
            className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div className="text-[10px] font-mono text-slate-400 mb-1 px-1">
              {msg.sender === 'user' ? 'YOU' : 'SOURCE AI'} � {msg.timestamp}
            </div>

            <div
              className={`rounded-2xl p-4 max-w-[92%] leading-relaxed text-sm ${
                msg.sender === 'user'
                  ? 'bg-emerald-600/90 text-white rounded-tr-none shadow-md'
                  : 'bg-slate-900/90 border border-slate-800 text-slate-200 rounded-tl-none shadow-xl'
              }`}
            >
              <p className="font-semibold">{msg.text}</p>

              {/* Structured Details */}
              {msg.structuredDetails && (
                <div className="mt-3 pt-3 border-t border-slate-800/80 space-y-3">
                  {msg.structuredDetails.title && (
                    <div className="text-xs font-mono uppercase tracking-wider text-slate-400 font-bold">
                      {msg.structuredDetails.title}
                    </div>
                  )}

                  {/* Key Stats */}
                  {msg.structuredDetails.stats && (
                    <div className="grid grid-cols-1 gap-1.5 bg-slate-950/60 p-2.5 rounded-lg border border-slate-800">
                      {msg.structuredDetails.stats.map((st, idx) => (
                        <div key={idx} className="flex items-center justify-between text-xs">
                          <span className="text-slate-400">{st.label}</span>
                          <span className={`font-mono font-bold ${st.color || 'text-white'}`}>
                            {st.value}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Causes */}
                  {msg.structuredDetails.causes && (
                    <div className="space-y-1">
                      <span className="text-[11px] font-mono text-slate-400 uppercase">Diagnosed Root Causes:</span>
                      <ul className="list-disc list-inside text-xs text-slate-300 space-y-1">
                        {msg.structuredDetails.causes.map((c, idx) => (
                          <li key={idx}>{c}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Action buttons */}
                  {msg.structuredDetails.actions && (
                    <div className="pt-2 flex flex-col gap-1.5">
                      {msg.structuredDetails.actions.map((act, idx) => (
                        <button
                          key={idx}
                          onClick={() => {
                            if (act.route) {
                              onNavigate(act.route);
                              onClose();
                            }
                          }}
                          className="flex items-center justify-between text-xs px-3 py-2 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 rounded border border-emerald-500/30 transition group"
                        >
                          <span className="font-medium">{act.label}</span>
                          <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}

        {isProcessing && (
          <div className="flex items-center gap-2 text-xs font-mono text-slate-400 p-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            Synthesizing telemetry across campus nodes...
          </div>
        )}
      </div>

      {/* Input */}
      <div className="p-3 border-t border-slate-800 bg-slate-900/80">
        <form
          onSubmit={e => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            placeholder="Ask SOURCE AI about campus resources, leaks, matches..."
            className="flex-1 bg-slate-950 border border-slate-700/80 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
          />
          <button
            type="submit"
            className="p-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl font-bold transition shadow-lg shadow-emerald-500/20"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
