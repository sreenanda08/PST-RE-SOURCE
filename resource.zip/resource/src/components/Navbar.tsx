import React, { useState } from 'react';
import { useResource } from '../context/ResourceContext';
import {
  Activity,
  Layers,
  MapPin,
  TrendingUp,
  GitCompare,
  ShoppingBag,
  Trash2,
  AlertOctagon,
  Award,
  FileText,
  Bot,
  Settings,
  Radio,
  Play,
  Menu,
  X,
  Compass
} from 'lucide-react';

interface Props {
  currentRoute: string;
  onNavigate: (route: string) => void;
  onOpenAiDrawer: () => void;
}

export const Navbar: React.FC<Props> = ({ currentRoute, onNavigate, onOpenAiDrawer }) => {
  const {
    isSimulating,
    toggleSimulation,
    startCompetitionDemo,
    isDemoRunning,
    alerts,
  } = useResource();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const unreadAlerts = alerts.filter(a => a.status === 'DETECTED').length;

  const navLinks = [
    { path: '/dashboard', label: 'Command Center', icon: Activity },
    { path: '/resources', label: 'Intelligence', icon: Layers },
    { path: '/forecast', label: 'Prediction', icon: TrendingUp },
    { path: '/matches', label: 'Matching', icon: GitCompare, highlight: true },
    { path: '/exchange', label: 'Exchange', icon: ShoppingBag },
    { path: '/map', label: 'Live Map', icon: MapPin },
    { path: '/waste', label: 'Waste', icon: Trash2 },
    { path: '/alerts', label: 'Alerts', icon: AlertOctagon, badge: unreadAlerts > 0 ? unreadAlerts : undefined },
    { path: '/impact', label: 'Impact', icon: Award },
    { path: '/reports', label: 'Reports', icon: FileText },
    { path: '/ai', label: 'Copilot', icon: Bot },
    { path: '/settings', label: 'Settings', icon: Settings },
  ];

  return (
    <header className="sticky top-0 z-50 bg-[#090d16]/95 border-b border-slate-800/80 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-2">
        {/* Logo */}
        <div
          onClick={() => onNavigate('/')}
          className="flex items-center gap-2.5 cursor-pointer group shrink-0"
        >
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-emerald-500 via-teal-400 to-cyan-500 flex items-center justify-center shadow-lg shadow-emerald-500/20 group-hover:scale-105 transition-transform">
            <span className="font-mono font-extrabold text-slate-950 text-sm">RE</span>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold tracking-wider text-base text-white">RE:SOURCE</span>
              <span className="text-[9px] font-mono uppercase bg-emerald-500/20 text-emerald-400 px-1.5 py-0.2 rounded border border-emerald-500/30">
                OS v2.4
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-mono hidden sm:block">Resource Intelligence Control</p>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden xl:flex items-center gap-1">
          {navLinks.map(link => {
            const Icon = link.icon;
            const isActive = currentRoute === link.path;
            return (
              <button
                key={link.path}
                onClick={() => onNavigate(link.path)}
                className={`relative px-2.5 py-1.5 rounded-lg text-xs font-medium transition flex items-center gap-1.5 ${
                  isActive
                    ? 'text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 shadow-sm'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-emerald-400' : 'text-slate-400'}`} />
                <span>{link.label}</span>
                {link.badge && (
                  <span className="w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] font-bold flex items-center justify-center animate-pulse">
                    {link.badge}
                  </span>
                )}
                {link.highlight && !isActive && (
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* IoT Simulation Toggle */}
          <button
            onClick={toggleSimulation}
            title={isSimulating ? 'IoT Stream Live (Click to pause)' : 'IoT Stream Paused (Click to resume)'}
            className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-mono border transition ${
              isSimulating
                ? 'bg-slate-900 text-emerald-400 border-emerald-500/30'
                : 'bg-slate-900 text-slate-400 border-slate-800'
            }`}
          >
            <Radio className={`w-3 h-3 ${isSimulating ? 'text-emerald-400 animate-pulse' : 'text-slate-500'}`} />
            <span>{isSimulating ? 'IoT LIVE' : 'IoT PAUSED'}</span>
          </button>

          {/* Competition Mode button */}
          <button
            onClick={startCompetitionDemo}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition shadow-sm ${
              isDemoRunning
                ? 'bg-emerald-500 text-slate-950 shadow-emerald-500/30'
                : 'bg-gradient-to-r from-amber-500/20 to-emerald-500/20 text-amber-300 hover:text-white border border-amber-500/40 hover:bg-amber-500/30'
            }`}
          >
            <Play className="w-3 h-3 fill-current" />
            <span className="hidden sm:inline">DEMO MODE</span>
          </button>

          {/* Persistent Source AI Drawer Trigger */}
          <button
            onClick={onOpenAiDrawer}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 transition shadow-sm"
          >
            <Bot className="w-3.5 h-3.5 text-emerald-400" />
            <span>SOURCE AI</span>
          </button>

          {/* Mobile hamburger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="xl:hidden p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="xl:hidden border-t border-slate-800 bg-[#090d16] p-4 max-h-[80vh] overflow-y-auto">
          <div className="grid grid-cols-2 gap-2">
            {navLinks.map(link => {
              const Icon = link.icon;
              const isActive = currentRoute === link.path;
              return (
                <button
                  key={link.path}
                  onClick={() => {
                    onNavigate(link.path);
                    setMobileMenuOpen(false);
                  }}
                  className={`p-2.5 rounded-xl text-xs font-medium flex items-center gap-2 text-left ${
                    isActive
                      ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 font-bold'
                      : 'bg-slate-900/60 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <Icon className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="truncate">{link.label}</span>
                  {link.badge && (
                    <span className="ml-auto w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] font-bold flex items-center justify-center">
                      {link.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </header>
  );
};
