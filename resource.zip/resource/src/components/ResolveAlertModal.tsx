import React, { useState } from 'react';
import { useResource } from '../context/ResourceContext';
import { X, CheckCircle, AlertTriangle } from 'lucide-react';

interface Props {
  alertId: string | null;
  onClose: () => void;
}

export const ResolveAlertModal: React.FC<Props> = ({ alertId, onClose }) => {
  const { alerts, resolveAlert } = useResource();
  const [notes, setNotes] = useState('Technician deployed on site. Isolated Sub-line Valve W-04 and verified zero further leakage.');

  if (!alertId) return null;
  const alert = alerts.find(a => a.id === alertId);
  if (!alert) return null;

  const handleResolve = () => {
    resolveAlert(alertId, notes);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-lg bg-[#0e1628] border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden">
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-white text-base">Resolve Anomaly Alert</h3>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
            <div className="text-xs font-mono uppercase text-slate-400">Target Facility & Issue</div>
            <div className="text-sm font-bold text-white mt-1">{alert.title}</div>
            <div className="text-xs text-slate-400 mt-0.5">{alert.facility} � Deviation: {alert.deviation}</div>
          </div>

          <div>
            <label className="block text-xs font-mono uppercase text-slate-400 mb-1">
              Corrective Action Audit Notes
            </label>
            <textarea
              rows={3}
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="pt-2 flex justify-end gap-2 border-t border-slate-800">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white rounded-lg bg-slate-800 hover:bg-slate-700 transition"
            >
              Cancel
            </button>
            <button
              onClick={handleResolve}
              className="px-5 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition font-bold shadow-lg shadow-emerald-500/20"
            >
              Confirm Resolution & Close Alert
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
