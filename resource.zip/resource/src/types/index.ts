export type ResourceCategory =
  | 'Materials'
  | 'Food'
  | 'Water'
  | 'Energy'
  | 'Furniture'
  | 'Electronics'
  | 'Paper'
  | 'Plastic'
  | 'Metal'
  | 'Construction materials'
  | 'Laboratory materials'
  | 'Packaging';

export type AlertSeverity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'INFO';

export interface TelemetryMetric {
  type: 'WATER' | 'ENERGY' | 'FOOD' | 'MATERIALS' | 'WASTE';
  name: string;
  currentValue: number;
  baselineValue: number;
  unit: string;
  trendPercentage: number;
  status: 'OPTIMAL' | 'ELEVATED' | 'CRITICAL' | 'SURPLUS';
  aiDetection: string;
  recommendedAction: string;
  efficiencyScore: number;
  hourlyCurve: { hour: string; actual: number; baseline: number }[];
}

export interface FacilityNode {
  id: string;
  name: string;
  code: string;
  type: 'ACADEMIC' | 'CAFETERIA' | 'HOSTEL' | 'LAB' | 'WAREHOUSE' | 'WASTE_CENTER';
  x: number; // percentage in campus map (0-100)
  y: number; // percentage in campus map (0-100)
  status: 'normal' | 'warning' | 'critical' | 'surplus';
  currentConsumption: {
    waterL: number;
    energyKwh: number;
    foodKg: number;
    wasteKg: number;
  };
  activeAlertCount: number;
  meters: {
    id: string;
    meterType: 'Water' | 'Energy' | 'Waste';
    currentReading: number;
    baseline: number;
    unit: string;
    status: 'optimal' | 'anomaly';
  }[];
}

export interface ResourceListing {
  id: string;
  title: string;
  category: ResourceCategory;
  quantity: number;
  unit: string;
  condition: 'Fresh / Ready' | 'Surplus Untapped' | 'Gently Used' | 'Good Condition' | 'Recyclable Grade A';
  source: string;
  sourceFacilityId: string;
  availableUntil: string;
  location: string;
  priority: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  estimatedValueInr: number;
  co2AvoidedKg: number;
  status: 'AVAILABLE' | 'MATCHED' | 'IN_TRANSIT' | 'ALLOCATED' | 'COMPLETED';
  passportId: string;
  allocatedTo?: string;
  expiryHoursRemaining?: number;
}

export interface DemandNode {
  id: string;
  name: string;
  category: ResourceCategory;
  neededQuantity: number;
  unit: string;
  distanceKm: number;
  urgency: 'CRITICAL' | 'HIGH' | 'MEDIUM';
  transitMinutes: number;
  acceptanceHours: string;
  facilityType: string;
}

export interface MatchRecommendation {
  id: string;
  surplusId: string;
  surplusTitle: string;
  surplusQuantity: number;
  unit: string;
  sourceFacility: string;
  destinations: {
    demandId: string;
    destinationName: string;
    distanceKm: number;
    allocatedQuantity: number;
    transitMinutes: number;
  }[];
  totalAllocated: number;
  wasteAvoidedKg: number;
  co2AvoidedKg: number;
  estimatedTransitTimeMin: number;
  financialSavedInr: number;
  matchScore: number; // 0 - 100
  factors: {
    quantityFit: number;
    distanceProximity: number;
    urgencyPriority: number;
    storageCompatibility: number;
    carbonOffsetEfficiency: number;
  };
  status: 'PENDING_APPROVAL' | 'APPROVED' | 'DISPATCHED' | 'DELIVERED';
}

export interface ResourceTransfer {
  id: string;
  resourceId: string;
  resourceTitle: string;
  category: ResourceCategory;
  quantity: number;
  unit: string;
  fromNode: string;
  toNode: string;
  startTime: string;
  eta: string;
  status: 'DISPATCHED' | 'IN_TRANSIT' | 'ARRIVED' | 'VERIFIED';
  courier: string;
  carbonSavedKg: number;
  valueRecoveredInr: number;
}

export interface AnomalyAlert {
  id: string;
  title: string;
  severity: AlertSeverity;
  resourceType: 'Water' | 'Energy' | 'Food' | 'Materials' | 'Waste';
  facility: string;
  deviation: string;
  probableCause: string;
  recommendedAction: string;
  detectedAt: string;
  status: 'DETECTED' | 'ACKNOWLEDGED' | 'ASSIGNED' | 'RESOLVED' | 'IGNORED';
  assignedTo?: string;
  resolutionNotes?: string;
}

export interface ResourcePassport {
  id: string;
  resourceId: string;
  resourceName: string;
  category: ResourceCategory;
  quantity: number;
  unit: string;
  createdTimestamp: string;
  expiryTimestamp: string;
  sourceFacility: string;
  currentCustodian: string;
  carbonFootprintAvoidedKg: number;
  economicValueInr: number;
  storageRequirements: string;
  safetyCertification: string;
  qrPayload: string;
  custodyHistory: {
    timestamp: string;
    event: string;
    actor: string;
    location: string;
  }[];
  status: 'AUTHENTICATED' | 'ALLOCATED' | 'TRANSFERRED' | 'RECOVERED';
}

export interface ForecastData {
  category: string;
  todayValue: number;
  tomorrowValue: number;
  predictedSurplus: number;
  confidencePercentage: number;
  recommendedProduction: number;
  unit: string;
  chartData: {
    time: string;
    historical?: number;
    baseline: number;
    predicted: number;
    upperBound: number;
    lowerBound: number;
  }[];
}

export interface WasteHotspotItem {
  id: string;
  facility: string;
  category: string;
  wasteDeviation: string;
  trend: 'up' | 'down';
  likelyCause: string;
  aiRecommendation: string;
  costImpactInr: number;
  preventableKg: number;
}

export interface ImpactMetrics {
  healthScore: number;
  waterSavedLiters: number;
  energySavedKwh: number;
  foodRedirectedKg: number;
  materialsReusedKg: number;
  wastePreventedKg: number;
  costRecoveredInr: number;
  co2AvoidedTonnes: number;
}

export interface AiMessage {
  id: string;
  sender: 'user' | 'assistant';
  timestamp: string;
  text: string;
  structuredDetails?: {
    title?: string;
    stats?: { label: string; value: string; color?: string }[];
    causes?: string[];
    actions?: { label: string; route?: string; actionType?: string }[];
  };
}

